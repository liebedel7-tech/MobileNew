/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, Consumer, MeterReader, WaterMeter, MeterReading, RouteAssignment, Announcement, AuditLog, ConsumerNotification, Barangay, ConsumerReport, ConsumerReportReply, WaterMeterInstallationRequest, InstallationStatus, InstallationHistoryEntry } from './types';
import { 
  WaterTariffConfig, 
  getActiveTariffConfig, 
  saveActiveTariffConfig, 
  DEFAULT_TARIFF_CONFIG,
  OFFICIAL_TARIFF_BASELINE_SCHEMA,
  normalizeReadingToOfficialBaseline
} from './utils/tariffCalculator';
import { 
  initializeFirestoreSeed, 
  syncBatchToFirestore, 
  syncDocToFirestore, 
  deleteDocFromFirestore, 
  eraseAccountFromFirestore,
  pushIssuedConsumerToFirestore,
  isAccountTerminated,
  addTerminatedAccountKeys,
  removeTerminatedAccountKeys,
  isRealIssuedAccountNumber,
  normalizeConsumerRecord,
  COLLECTIONS 
} from './services/firebaseDb';
import { safeBackendFetch } from './services/apiClient';
import {
  dedupeNotifications,
  getNotificationSemanticKey,
  isIssuedNotifAccount,
  normalizeNotifAccount,
} from './utils/notificationDeduper';
import {
  inferNotificationType,
  isPersonalNotificationType,
  isTransactionalPaymentOrReceiptItem,
  sanitizeAnnouncements,
} from './utils/announcementSanitizer';
import {
  isPendingConsumerStatus,
  generateApplicationNumber,
  buildInstallationReceivedNotification,
  buildInstallationStatusUpdateNotification,
  buildAccountActivatedAfterInstallationNotification,
} from './utils/installationWorkflow';
import {
  compareAnnouncementsCanonical,
  compareAuditLogsCanonical,
  compareBarangaysCanonical,
  compareConsumersCanonical,
  compareInstallationsCanonical,
  compareMetersCanonical,
  compareReadersCanonical,
  compareReadingsCanonical,
  compareReportsCanonical,
  compareRoutesCanonical,
  compareUsersCanonical,
  ensureMeterSerialNumber,
} from './utils/canonicalSort';
import { computeOdometerConsumption } from './utils/odometer';


// Purge all legacy storage keys containing old mock data
try {
  const legacyPrefixes = ['twd_', 'twd_v1_', 'twd_v2_', 'water_district_', 'twd_live_v1_', 'twd_live_v2_', 'twd_live_v3_'];
  const keysToPurge: string[] = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && legacyPrefixes.some(p => k.startsWith(p)) && !k.startsWith('twd_live_v4_')) {
      keysToPurge.push(k);
    }
  }
  keysToPurge.forEach(k => localStorage.removeItem(k));
} catch (e) {
  // Safe failover
}

// Storage keys
const STORAGE_PREFIX = 'twd_live_v4_';
const KEYS = {
  USERS: `${STORAGE_PREFIX}users`,
  CONSUMERS: `${STORAGE_PREFIX}consumers`,
  READERS: `${STORAGE_PREFIX}readers`,
  METERS: `${STORAGE_PREFIX}meters`,
  READINGS: `${STORAGE_PREFIX}readings`,
  ROUTES: `${STORAGE_PREFIX}routes`,
  ANNOUNCEMENTS: `${STORAGE_PREFIX}announcements`,
  AUDIT_LOGS: `${STORAGE_PREFIX}audit_logs`,
  NOTIFICATIONS: `${STORAGE_PREFIX}notifications`,
  CURRENT_USER: `${STORAGE_PREFIX}current_user`,
  BARANGAYS: `${STORAGE_PREFIX}barangays`,
  TARIFF_CONFIG: `${STORAGE_PREFIX}tariff_config`,
  REPORTS: `${STORAGE_PREFIX}consumer_reports`,
  INSTALLATIONS: `${STORAGE_PREFIX}installations`,
  ADMIN_READ_ALERTS: `${STORAGE_PREFIX}admin_read_alerts`,
};

function getAdminReadAlertTokens(): Set<string> {
  try {
    const raw = localStorage.getItem(KEYS.ADMIN_READ_ALERTS);
    if (!raw) return new Set<string>();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? new Set<string>(parsed.map(String)) : new Set<string>();
  } catch {
    return new Set<string>();
  }
}

function addAdminReadAlertTokens(tokens: string[]): void {
  if (!tokens || tokens.length === 0) return;
  try {
    const current = getAdminReadAlertTokens();
    tokens.forEach((t) => {
      if (t) current.add(t);
    });
    const list = Array.from(current).slice(-600);
    localStorage.setItem(KEYS.ADMIN_READ_ALERTS, JSON.stringify(list));
  } catch {
    // Safe failover
  }
}

function getAdminInstallationAlertToken(req: WaterMeterInstallationRequest): string {
  const consumerEvents = Array.isArray(req.history)
    ? req.history.filter((h) => h && h.actorRole === 'consumer').length
    : 0;
  return `inst::${req.id || req.applicationNumber}::${req.status}::${req.accountValidationStatus || 'pending'}::${consumerEvents}`;
}

function getAdminReportAlertToken(rep: ConsumerReport): string {
  const consumerReplies = Array.isArray(rep.replies)
    ? rep.replies.filter((m) => m && m.senderRole === 'consumer').length
    : 0;
  return `rep::${rep.id || rep.ticketNumber}::${consumerReplies}`;
}

// Initial Sample Consumer Reports
const INITIAL_REPORTS: ConsumerReport[] = [
  {
    id: 'REP-2024-001',
    ticketNumber: 'TWD-CR-2024-001',
    accountNumber: 'BRG-01-3117',
    consumerName: 'Bruce Acero',
    consumerEmail: 'acero@gmail.com',
    consumerPhone: '+63 917 888 2345',
    barangay: 'Poblacion',
    address: 'PUROK 3, POBLACION',
    meterNumber: '150309988',
    category: 'leak',
    title: 'Water Leak along Purok 3 main connection pipe',
    description: 'Noticeable water bubbling out from underground pipe near the meter box outside our gate. Significant drop of pressure observed in our household.',
    urgency: 'urgent',
    status: 'in_progress',
    createdAt: '2024-10-14T08:30:00.000Z',
    updatedAt: '2024-10-14T09:15:00.000Z',
    assignedStaff: 'Field Maintenance Crew - Team Alpha',
    replies: [
      {
        id: 'REP-MSG-001',
        reportId: 'REP-2024-001',
        senderId: 'user-acero',
        senderName: 'Bruce Acero',
        senderRole: 'consumer',
        message: 'Noticeable water bubbling out from underground pipe near the meter box outside our gate. Significant drop of pressure observed in our household.',
        timestamp: '2024-10-14T08:30:00.000Z'
      },
      {
        id: 'REP-MSG-002',
        reportId: 'REP-2024-001',
        senderId: 'admin-1',
        senderName: 'TWD Operations Admin',
        senderRole: 'admin',
        message: 'Good morning Mr. Acero. We have logged your concern and dispatched Field Maintenance Crew (Team Alpha) led by Engr. Morales to inspect the underground coupling at Purok 3.',
        timestamp: '2024-10-14T09:15:00.000Z',
        statusUpdate: 'in_progress'
      }
    ],
    hasUnreadAdminReply: true,
    hasUnreadConsumerUpdate: false
  },
  {
    id: 'REP-2024-002',
    ticketNumber: 'TWD-CR-2024-002',
    accountNumber: '011-102-056',
    consumerName: 'FIGUEROA, GINA O.',
    consumerEmail: 'gina.figueroa@gmail.com',
    consumerPhone: '+63 917 123 4567',
    barangay: 'Poblacion',
    address: 'SIHAYON-LEFT (ZONE-11A)',
    meterNumber: '150307143',
    category: 'billing',
    title: 'Inquiry regarding October Consumption Breakdown',
    description: 'Requesting confirmation on whether late penalty is waived before due date. Would like clarification on franchise tax calculation.',
    urgency: 'normal',
    status: 'resolved',
    createdAt: '2024-10-10T10:00:00.000Z',
    updatedAt: '2024-10-10T11:20:00.000Z',
    resolvedAt: '2024-10-10T11:20:00.000Z',
    assignedStaff: 'Billing Department Desk 2',
    replies: [
      {
        id: 'REP-MSG-003',
        reportId: 'REP-2024-002',
        senderId: 'consumer-gina',
        senderName: 'Gina Figueroa',
        senderRole: 'consumer',
        message: 'Requesting confirmation on whether late penalty is waived before due date. Would like clarification on franchise tax calculation.',
        timestamp: '2024-10-10T10:00:00.000Z'
      },
      {
        id: 'REP-MSG-004',
        reportId: 'REP-2024-002',
        senderId: 'admin-1',
        senderName: 'TWD Billing Supervisor',
        senderRole: 'admin',
        message: 'Hello Ms. Figueroa! The 10% late surcharge is strictly applied only after the due date. The 2% franchise tax is mandated by national utility regulations. Your current statement is valid for normal payment.',
        timestamp: '2024-10-10T11:20:00.000Z',
        statusUpdate: 'resolved'
      }
    ],
    hasUnreadAdminReply: false,
    hasUnreadConsumerUpdate: false
  }
];

// Initial Clean Seed Data - Tagoloan Municipal Barangays
const INITIAL_BARANGAYS: Barangay[] = [
  { id: 'BRG-01', name: 'Poblacion', code: 'PB-01', consumers: 0, activeMeters: 0, schedule: '1st - 5th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-02', name: 'Natumolan', code: 'NT-02', consumers: 0, activeMeters: 0, schedule: '6th - 10th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-03', name: 'Baluarte', code: 'BL-03', consumers: 0, activeMeters: 0, schedule: '11th - 15th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-04', name: 'Sta. Ana', code: 'SA-04', consumers: 0, activeMeters: 0, schedule: '16th - 20th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-05', name: 'Sta. Cruz', code: 'SC-05', consumers: 0, activeMeters: 0, schedule: '21st - 25th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-06', name: 'Mohon', code: 'MH-06', consumers: 0, activeMeters: 0, schedule: '26th - End of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-07', name: 'Gracia', code: 'GR-07', consumers: 0, activeMeters: 0, schedule: '1st - 5th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-08', name: 'Casinglot', code: 'CS-08', consumers: 0, activeMeters: 0, schedule: '6th - 10th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-09', name: 'Sugbongcogon', code: 'SG-09', consumers: 0, activeMeters: 0, schedule: '11th - 15th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
  { id: 'BRG-10', name: 'Rosario', code: 'RS-10', consumers: 0, activeMeters: 0, schedule: '16th - 20th of Month', supervisor: 'District Operations Supervisor', ratePerM3: 10.00 },
];

const INITIAL_USERS: User[] = [
  {
    id: 'admin-1',
    email: 'admin@tagoloanwater.gov.ph',
    name: 'Admin',
    role: 'admin',
    status: 'active',
    password: 'AdminWater2025!',
  },
];

const INITIAL_CONSUMERS: Consumer[] = [
  {
    accountNumber: '011-102-056',
    name: 'FIGUEROA, GINA O.',
    address: 'SIHAYON-LEFT (ZONE-11A)',
    barangay: 'Poblacion',
    sitioZone: 'ZONE-11A',
    contactNumber: '+63 917 123 4567',
    email: 'gina.figueroa@gmail.com',
    meterNumber: '150307143',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-01-15',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '4 members',
    outstandingBalance: 205.03,
    rfidTag: 'RFID-150307143',
    sequenceNo: 135,
  },
  {
    accountNumber: '011-302-053',
    name: 'ELLO, CARMEN',
    address: 'SIHAYON-LEFT',
    barangay: 'Poblacion',
    sitioZone: 'Sihayon-Left',
    contactNumber: '+63 918 234 5678',
    email: 'carmen.ello@gmail.com',
    meterNumber: 'E180103545',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-02-10',
    consumerType: 'Commercial',
    businessName: 'Ello Enterprise / Store',
    businessType: 'Retail & Commercial',
    meterSize: '3/4"',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-E180103545',
    sequenceNo: 136,
  },
  {
    accountNumber: '011-102-042',
    name: 'OKLAND AIDALIN 1 / LLERA',
    address: 'SIHAYON-LEFT',
    barangay: 'Poblacion',
    sitioZone: 'Sihayon-Left',
    contactNumber: '+63 919 345 6789',
    email: 'aidalin.llera@gmail.com',
    meterNumber: '121111102',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-03-05',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '3 members',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-121111102',
    sequenceNo: 137,
  },
  {
    accountNumber: '022-204-118',
    name: 'SABIO, EDUARDO P.',
    address: 'PUROK 2, NATUMOLAN',
    barangay: 'Natumolan',
    barangayId: 'BRG-02',
    sitioZone: 'Purok 2',
    contactNumber: '+63 919 333 4455',
    email: 'eduardo.sabio@gmail.com',
    meterNumber: '160408221',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-01-20',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '4 members',
    outstandingBalance: 180.50,
    rfidTag: 'RFID-160408221',
    sequenceNo: 201,
  },
  {
    accountNumber: '022-501-094',
    name: 'MAGPALE, TERESITA L.',
    address: 'COASTAL ROAD, NATUMOLAN',
    barangay: 'Natumolan',
    barangayId: 'BRG-02',
    sitioZone: 'Zone 5',
    contactNumber: '+63 917 555 7890',
    email: 'teresita.magpale@gmail.com',
    meterNumber: '160409934',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-02-15',
    consumerType: 'Commercial',
    businessName: 'Magpale Trading',
    businessType: 'General Merchandise',
    meterSize: '3/4"',
    outstandingBalance: 420.00,
    rfidTag: 'RFID-160409934',
    sequenceNo: 202,
  },
  {
    accountNumber: '033-101-077',
    name: 'CABALLES, ROLANDO B.',
    address: 'HIGHWAY PROPER, BALUARTE',
    barangay: 'Baluarte',
    barangayId: 'BRG-03',
    sitioZone: 'Zone 9',
    contactNumber: '+63 920 444 8899',
    email: 'rolando.caballes@gmail.com',
    meterNumber: '170501123',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-01-25',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '5 members',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-170501123',
    sequenceNo: 301,
  },
  {
    accountNumber: '033-202-088',
    name: 'MERCADO, ANICETO C.',
    address: 'RIVERSIDE DRIVE, BALUARTE',
    barangay: 'Baluarte',
    barangayId: 'BRG-03',
    sitioZone: 'Zone 10',
    contactNumber: '+63 921 555 3322',
    email: 'aniceto.mercado@gmail.com',
    meterNumber: '170502234',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-03-10',
    consumerType: 'Commercial',
    businessName: 'Mercado Auto Repair',
    businessType: 'Services',
    meterSize: '3/4"',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-170502234',
    sequenceNo: 302,
  },
  {
    accountNumber: '044-101-019',
    name: 'VALDEZ, RAMON S.',
    address: 'STA. ANA CENTRAL, STA. ANA',
    barangay: 'Sta. Ana',
    barangayId: 'BRG-04',
    sitioZone: 'Zone 13',
    contactNumber: '+63 922 666 4411',
    email: 'ramon.valdez@gmail.com',
    meterNumber: '180601345',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-02-01',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '3 members',
    outstandingBalance: 145.25,
    rfidTag: 'RFID-180601345',
    sequenceNo: 401,
  },
  {
    accountNumber: '044-202-044',
    name: 'PACAÑA, MERLITA G.',
    address: 'CROSSING STA. ANA, STA. ANA',
    barangay: 'Sta. Ana',
    barangayId: 'BRG-04',
    sitioZone: 'Zone 14',
    contactNumber: '+63 923 777 5522',
    email: 'merlita.pacana@gmail.com',
    meterNumber: '180602456',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-03-12',
    consumerType: 'Commercial',
    businessName: 'Pacaña Eatery & Refreshment',
    businessType: 'Food & Beverage',
    meterSize: '3/4"',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-180602456',
    sequenceNo: 402,
  },
  {
    accountNumber: '055-101-032',
    name: 'YBAÑEZ, DANILO M.',
    address: 'STA. CRUZ VALLEY, STA. CRUZ',
    barangay: 'Sta. Cruz',
    barangayId: 'BRG-05',
    sitioZone: 'Zone 17',
    contactNumber: '+63 925 888 6633',
    email: 'danilo.ybanez@gmail.com',
    meterNumber: '190701567',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-01-28',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '4 members',
    outstandingBalance: 210.00,
    rfidTag: 'RFID-190701567',
    sequenceNo: 501,
  },
  {
    accountNumber: '055-202-061',
    name: 'CASIÑO, ROWENA T.',
    address: 'PUROK 4, STA. CRUZ',
    barangay: 'Sta. Cruz',
    barangayId: 'BRG-05',
    sitioZone: 'Zone 18',
    contactNumber: '+63 926 999 7744',
    email: 'rowena.casino@gmail.com',
    meterNumber: '190702678',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-02-18',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '5 members',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-190702678',
    sequenceNo: 502,
  },
  {
    accountNumber: '066-202-045',
    name: 'DAGANATO, VICENTE K.',
    address: 'MOHON INDUSTRIAL CORRIDOR, MOHON',
    barangay: 'Mohon',
    barangayId: 'BRG-06',
    sitioZone: 'Zone 11',
    contactNumber: '+63 922 777 6611',
    email: 'vicente.daganato@gmail.com',
    meterNumber: '180602345',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-02-22',
    consumerType: 'Commercial',
    businessName: 'Daganato Metalworks & Hardware',
    businessType: 'Industrial / Commercial',
    meterSize: '1"',
    outstandingBalance: 580.00,
    rfidTag: 'RFID-180602345',
    sequenceNo: 601,
  },
  {
    accountNumber: '066-101-089',
    name: 'JADMAN, ELEUTERIO R.',
    address: 'FOOTHILL PUROK 2, MOHON',
    barangay: 'Mohon',
    barangayId: 'BRG-06',
    sitioZone: 'Zone 12',
    contactNumber: '+63 927 111 8855',
    email: 'eleuterio.jadman@gmail.com',
    meterNumber: '180603789',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-03-15',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '3 members',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-180603789',
    sequenceNo: 602,
  },
  {
    accountNumber: '077-101-023',
    name: 'RIVERA, FEDERICO D.',
    address: 'GRACIA PROPER, GRACIA',
    barangay: 'Gracia',
    barangayId: 'BRG-07',
    sitioZone: 'Zone 25',
    contactNumber: '+63 928 222 9966',
    email: 'federico.rivera@gmail.com',
    meterNumber: '200801122',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-01-30',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '4 members',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-200801122',
    sequenceNo: 701,
  },
  {
    accountNumber: '077-202-054',
    name: 'GORRES, ISIDRA M.',
    address: 'PUROK 3, GRACIA',
    barangay: 'Gracia',
    barangayId: 'BRG-07',
    sitioZone: 'Zone 26',
    contactNumber: '+63 929 333 0077',
    email: 'isidra.gorres@gmail.com',
    meterNumber: '200802233',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-02-28',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '2 members',
    outstandingBalance: 120.00,
    rfidTag: 'RFID-200802233',
    sequenceNo: 702,
  },
  {
    accountNumber: '088-101-011',
    name: 'LABIS, GREGORIO F.',
    address: 'CASINGLOT COASTAL, CASINGLOT',
    barangay: 'Casinglot',
    barangayId: 'BRG-08',
    sitioZone: 'Zone 21',
    contactNumber: '+63 930 444 1188',
    email: 'gregorio.labis@gmail.com',
    meterNumber: '210901344',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-02-05',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '6 members',
    outstandingBalance: 245.00,
    rfidTag: 'RFID-210901344',
    sequenceNo: 801,
  },
  {
    accountNumber: '088-202-076',
    name: 'RANISES, EMMA L.',
    address: 'SEASIDE BLVD, CASINGLOT',
    barangay: 'Casinglot',
    barangayId: 'BRG-08',
    sitioZone: 'Zone 22',
    contactNumber: '+63 931 555 2299',
    email: 'emma.ranises@gmail.com',
    meterNumber: '210902455',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-03-01',
    consumerType: 'Commercial',
    businessName: 'Ranises Beachside Resort',
    businessType: 'Hospitality / Commercial',
    meterSize: '1"',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-210902455',
    sequenceNo: 802,
  },
  {
    accountNumber: '099-101-098',
    name: 'ZAMBRANO, CRISANTO P.',
    address: 'SUGBONGCOGON HIGHWAY, SUGBONGCOGON',
    barangay: 'Sugbongcogon',
    barangayId: 'BRG-09',
    sitioZone: 'Zone 33',
    contactNumber: '+63 932 666 3300',
    email: 'crisanto.zambrano@gmail.com',
    meterNumber: '221001566',
    meterBrand: 'EVER',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-01-18',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '4 members',
    outstandingBalance: 0.00,
    rfidTag: 'RFID-221001566',
    sequenceNo: 901,
  },
  {
    accountNumber: '099-202-033',
    name: 'BEJA, ALICIA N.',
    address: 'PUROK 1, SUGBONGCOGON',
    barangay: 'Sugbongcogon',
    barangayId: 'BRG-09',
    sitioZone: 'Zone 34',
    contactNumber: '+63 933 777 4411',
    email: 'alicia.beja@gmail.com',
    meterNumber: '221002677',
    meterBrand: 'EVJET',
    status: 'active',
    isRegistered: true,
    registrationDate: '2024-02-14',
    consumerType: 'Residential',
    meterSize: '1/2"',
    householdInfo: '3 members',
    outstandingBalance: 165.75,
    rfidTag: 'RFID-221002677',
    sequenceNo: 902,
  }
];

const INITIAL_READERS: MeterReader[] = [
  {
    id: 'reader-1',
    employeeId: 'TWD-2026-001',
    name: 'Marco Polo',
    username: 'marco_polo',
    password: 'password123',
    pin: '1234',
    email: 'marco_polo@tagoloanwater.gov.ph',
    contactNumber: '0917-555-0199',
    employmentStatus: 'active',
    assignedRoutes: ['Zone 1-4: Poblacion (Main Central)'],
    targetRoute: 'Zone 1-4: Poblacion (Main Central)',
    zone: 'Zone 1-4: Poblacion (Main Central)',
    completedReadings: 142,
    pendingReadings: 3,
    performanceRating: 4.9
  }
];

const INITIAL_METERS: WaterMeter[] = [
  {
    meterNumber: '150307143',
    serialNumber: 'SN-EVR-2024-7143',
    rfidTag: 'RFID-150307143',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-01-15',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 4393,
    status: 'active',
    linkedAccountNumber: '011-102-056'
  },
  {
    meterNumber: 'E180103545',
    serialNumber: 'SN-EVR-2024-3545',
    rfidTag: 'RFID-E180103545',
    brand: 'EVER',
    type: 'mechanical',
    size: '3/4"',
    installationDate: '2024-02-10',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 2204,
    status: 'active',
    linkedAccountNumber: '011-302-053'
  },
  {
    meterNumber: '121111102',
    serialNumber: 'SN-EVJ-2024-1102',
    rfidTag: 'RFID-121111102',
    brand: 'EVJET',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-03-05',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 2100,
    status: 'active',
    linkedAccountNumber: '011-102-042'
  },
  {
    meterNumber: '160408221',
    rfidTag: 'RFID-160408221',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-01-20',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1540,
    status: 'active',
    linkedAccountNumber: '022-204-118'
  },
  {
    meterNumber: '160409934',
    rfidTag: 'RFID-160409934',
    brand: 'EVJET',
    type: 'mechanical',
    size: '3/4"',
    installationDate: '2024-02-15',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 3210,
    status: 'active',
    linkedAccountNumber: '022-501-094'
  },
  {
    meterNumber: '170501123',
    rfidTag: 'RFID-170501123',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-01-25',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 2890,
    status: 'active',
    linkedAccountNumber: '033-101-077'
  },
  {
    meterNumber: '170502234',
    rfidTag: 'RFID-170502234',
    brand: 'EVJET',
    type: 'mechanical',
    size: '3/4"',
    installationDate: '2024-03-10',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1845,
    status: 'active',
    linkedAccountNumber: '033-202-088'
  },
  {
    meterNumber: '180601345',
    rfidTag: 'RFID-180601345',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-02-01',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1220,
    status: 'active',
    linkedAccountNumber: '044-101-019'
  },
  {
    meterNumber: '180602456',
    rfidTag: 'RFID-180602456',
    brand: 'EVJET',
    type: 'mechanical',
    size: '3/4"',
    installationDate: '2024-03-12',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 2430,
    status: 'active',
    linkedAccountNumber: '044-202-044'
  },
  {
    meterNumber: '190701567',
    rfidTag: 'RFID-190701567',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-01-28',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1980,
    status: 'active',
    linkedAccountNumber: '055-101-032'
  },
  {
    meterNumber: '190702678',
    rfidTag: 'RFID-190702678',
    brand: 'EVJET',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-02-18',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1450,
    status: 'active',
    linkedAccountNumber: '055-202-061'
  },
  {
    meterNumber: '180602345',
    rfidTag: 'RFID-180602345',
    brand: 'EVJET',
    type: 'mechanical',
    size: '1"',
    installationDate: '2024-02-22',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 5120,
    status: 'active',
    linkedAccountNumber: '066-202-045'
  },
  {
    meterNumber: '180603789',
    rfidTag: 'RFID-180603789',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-03-15',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 970,
    status: 'active',
    linkedAccountNumber: '066-101-089'
  },
  {
    meterNumber: '200801122',
    rfidTag: 'RFID-200801122',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-01-30',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1650,
    status: 'active',
    linkedAccountNumber: '077-101-023'
  },
  {
    meterNumber: '200802233',
    rfidTag: 'RFID-200802233',
    brand: 'EVJET',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-02-28',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1110,
    status: 'active',
    linkedAccountNumber: '077-202-054'
  },
  {
    meterNumber: '210901344',
    rfidTag: 'RFID-210901344',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-02-05',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 2240,
    status: 'active',
    linkedAccountNumber: '088-101-011'
  },
  {
    meterNumber: '210902455',
    rfidTag: 'RFID-210902455',
    brand: 'EVJET',
    type: 'mechanical',
    size: '1"',
    installationDate: '2024-03-01',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 3890,
    status: 'active',
    linkedAccountNumber: '088-202-076'
  },
  {
    meterNumber: '221001566',
    rfidTag: 'RFID-221001566',
    brand: 'EVER',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-01-18',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1780,
    status: 'active',
    linkedAccountNumber: '099-101-098'
  },
  {
    meterNumber: '221002677',
    rfidTag: 'RFID-221002677',
    brand: 'EVJET',
    type: 'mechanical',
    size: '1/2"',
    installationDate: '2024-02-14',
    lastReadingDate: '2024-10-15',
    lastReadingValue: 1340,
    status: 'active',
    linkedAccountNumber: '099-202-033'
  }
];

const INITIAL_READINGS: MeterReading[] = [
  {
    id: 'R-011-102-056-202410',
    accountNumber: '011-102-056',
    consumerName: 'FIGUEROA, GINA O.',
    meterNumber: '150307143',
    meterBrand: 'EVER',
    sequenceNo: 135,
    address: 'SIHAYON-LEFT (ZONE-11A)',
    addressZone: 'ZONE-11A',
    route: 'Sihayon-Left Route',
    previousReading: 4377,
    currentReading: 4393,
    consumption: 16,
    readingDate: '2024-10-15',
    meterReaderDate: '2024-10-15',
    status: 'verified',
    meterReaderName: 'MARCO POLO',
    imageUrl: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?w=600&auto=format&fit=crop&q=80',
    billingPeriod: 'October 2024',
    dueDate: 'December 12, 2024',
    classification: 'Residential',
    billAmount: 160.00,
    franchiseTax: 3.20,
    arrears: 205.03,
    totalAmount: 368.23,
    remainingBalance: 368.23,
    penaltyAmount: 16.00,
    amountAfterDueDate: 384.23,
    tariffBaselineSchema: OFFICIAL_TARIFF_BASELINE_SCHEMA,
    paymentStatus: 'unpaid',
    isBillingIssued: true,
  },
  {
    id: 'R-011-302-053-202410',
    accountNumber: '011-302-053',
    consumerName: 'ELLO, CARMEN',
    meterNumber: 'E180103545',
    meterBrand: 'EVER',
    sequenceNo: 136,
    address: 'SIHAYON-LEFT',
    addressZone: 'Sihayon-Left',
    route: 'Sihayon-Left Route',
    previousReading: 2139,
    currentReading: 2204,
    consumption: 65,
    readingDate: '2024-10-15',
    meterReaderDate: '2024-10-15',
    status: 'verified',
    meterReaderName: 'MARCO POLO',
    imageUrl: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?w=600&auto=format&fit=crop&q=80',
    billingPeriod: 'October 2024',
    dueDate: 'December 12, 2024',
    classification: 'Commercial',
    billAmount: 1625.00,
    franchiseTax: 32.50,
    arrears: 0.00,
    totalAmount: 1657.50,
    remainingBalance: 1657.50,
    penaltyAmount: 162.50,
    amountAfterDueDate: 1820.00,
    tariffBaselineSchema: OFFICIAL_TARIFF_BASELINE_SCHEMA,
    paymentStatus: 'unpaid',
    isBillingIssued: true,
  },
  {
    id: 'R-011-102-042-202410',
    accountNumber: '011-102-042',
    consumerName: 'OKLAND AIDALIN 1 / LLERA',
    meterNumber: '121111102',
    meterBrand: 'EVJET',
    sequenceNo: 137,
    address: 'SIHAYON-LEFT',
    addressZone: 'Sihayon-Left',
    route: 'Sihayon-Left Route',
    previousReading: 2083,
    currentReading: 2100,
    consumption: 17,
    readingDate: '2024-10-15',
    meterReaderDate: '2024-10-15',
    status: 'verified',
    meterReaderName: 'MARCO POLO',
    imageUrl: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?w=600&auto=format&fit=crop&q=80',
    billingPeriod: 'October 2024',
    dueDate: 'December 12, 2024',
    classification: 'Residential',
    billAmount: 170.00,
    franchiseTax: 3.40,
    arrears: 0.00,
    totalAmount: 173.40,
    remainingBalance: 173.40,
    penaltyAmount: 17.00,
    amountAfterDueDate: 190.40,
    tariffBaselineSchema: OFFICIAL_TARIFF_BASELINE_SCHEMA,
    paymentStatus: 'unpaid',
    isBillingIssued: true,
  },
  {
    id: 'R-022-204-118-PENDING',
    accountNumber: '022-204-118',
    consumerName: 'SABIO, EDUARDO P.',
    meterNumber: 'E180103546',
    meterBrand: 'EVER',
    sequenceNo: 140,
    address: 'PUROK 2, NATUMOLAN',
    addressZone: 'Purok 2',
    route: 'Natumolan Route 1',
    previousReading: 114,
    currentReading: 132,
    consumption: 18,
    readingDate: '2024-11-05',
    meterReaderDate: '2024-11-05',
    status: 'pending',
    meterReaderName: 'MARCO POLO',
    imageUrl: 'https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?q=80&w=300&auto=format&fit=crop',
    billingPeriod: 'November 2024',
    classification: 'Residential',
    notes: 'Normal residential consumption. Meter seal intact.'
  },
  {
    id: 'R-022-501-094-PENDING',
    accountNumber: '022-501-094',
    consumerName: 'MAGPALE, TERESITA L.',
    meterNumber: 'E180103547',
    meterBrand: 'EVER',
    sequenceNo: 141,
    address: 'COASTAL ROAD, NATUMOLAN',
    addressZone: 'Zone 5',
    route: 'Natumolan Route 1',
    previousReading: 240,
    currentReading: 264,
    consumption: 24,
    readingDate: '2024-11-05',
    meterReaderDate: '2024-11-05',
    status: 'flagged_abnormal',
    isAnomaly: true,
    anomalyReason: 'High Usage / Condition Alert — Verify',
    meterReaderName: 'MARCO POLO',
    imageUrl: 'https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?q=80&w=300&auto=format&fit=crop',
    billingPeriod: 'November 2024',
    classification: 'Residential',
    notes: 'Regular reading recorded on schedule.'
  },
  {
    id: 'R-033-101-077-PENDING',
    accountNumber: '033-101-077',
    consumerName: 'CABALLES, ROLANDO B.',
    meterNumber: 'E180103548',
    meterBrand: 'EVJET',
    sequenceNo: 142,
    address: 'HIGHWAY PROPER, BALUARTE',
    addressZone: 'Zone 9',
    route: 'Baluarte Riverside Route',
    previousReading: 85,
    currentReading: 104,
    consumption: 19,
    readingDate: '2024-11-05',
    meterReaderDate: '2024-11-05',
    status: 'pending',
    meterReaderName: 'JUAN DELA CRUZ',
    imageUrl: 'https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?q=80&w=300&auto=format&fit=crop',
    billingPeriod: 'November 2024',
    classification: 'Residential',
    notes: 'Dial inspected. No leak observed.'
  },
  {
    id: 'R-033-202-088-PENDING',
    accountNumber: '033-202-088',
    consumerName: 'MERCADO, ANICETO C.',
    meterNumber: 'E180103549',
    meterBrand: 'EVER',
    sequenceNo: 143,
    address: 'RIVERSIDE DRIVE, BALUARTE',
    addressZone: 'Zone 10',
    route: 'Baluarte Riverside Route',
    previousReading: 310,
    currentReading: 342,
    consumption: 32,
    readingDate: '2024-11-05',
    meterReaderDate: '2024-11-05',
    status: 'flagged_abnormal',
    isAnomaly: true,
    anomalyReason: 'High Usage / Condition Alert — Verify',
    meterReaderName: 'JUAN DELA CRUZ',
    imageUrl: 'https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?q=80&w=300&auto=format&fit=crop',
    billingPeriod: 'November 2024',
    classification: 'Commercial',
    notes: 'Commercial water service reading. Steady consumption.'
  }
];
const INITIAL_ROUTES: RouteAssignment[] = [];
const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Tagoloan Water District Live System Online',
    content: 'Welcome to the official Tagoloan Water District utility management system. Register your water service account or authenticate using municipal administration credentials.',
    date: '2026-08-18',
    category: 'info',
    postedBy: 'Administrative Office',
  }
];

const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    timestamp: new Date().toISOString(),
    userId: 'system',
    userName: 'TWD Core System',
    userRole: 'system',
    action: 'Database Initialized',
    details: 'System initialized with clean municipal registry and official administrator credentials.',
    ipAddress: '127.0.0.1',
  }
];

// Helper functions to fetch and save from/to localStorage
function getStored<T>(key: string, initial: T): T {
  const data = localStorage.getItem(key);
  if (!data) {
    const validInitial = Array.isArray(initial) 
      ? initial.filter((item: any) => !isAccountTerminated(item)) 
      : initial;
    localStorage.setItem(key, JSON.stringify(validInitial));
    return validInitial as unknown as T;
  }
  try {
    const parsed = JSON.parse(data);
    // Automatic cleanup of legacy mock test accounts & name normalization
    if (key === KEYS.READERS) {
      const readers = parsed as MeterReader[];
      const seenIds = new Set<string>();
      const deduplicatedReaders: MeterReader[] = [];
      readers.forEach(r => {
        if (isAccountTerminated(r)) return; // Strictly ignore terminated accounts
        const kId = (r.id || '').trim().toLowerCase();
        const kEmp = (r.employeeId || '').trim().toLowerCase();
        const kUser = (r.username || '').trim().toLowerCase();
        const kName = (r.name || '').trim().toLowerCase();
        const kEmail = (r.email || '').trim().toLowerCase();

        // If this reader matches ANY already seen reader by username, name, employeeId, id, or email, skip duplicate
        if (
          (kId && seenIds.has(kId)) ||
          (kEmp && seenIds.has(kEmp)) ||
          (kUser && seenIds.has(kUser)) ||
          (kName && seenIds.has(kName)) ||
          (kEmail && seenIds.has(kEmail))
        ) {
          return;
        }

        if (kId) seenIds.add(kId);
        if (kEmp) seenIds.add(kEmp);
        if (kUser) seenIds.add(kUser);
        if (kName) seenIds.add(kName);
        if (kEmail) seenIds.add(kEmail);
        deduplicatedReaders.push(r);
      });
      deduplicatedReaders.sort(compareReadersCanonical);
      const nextReadersJson = JSON.stringify(deduplicatedReaders);
      if (deduplicatedReaders.length !== readers.length || data !== nextReadersJson) {
        localStorage.setItem(key, nextReadersJson);
      }
      return deduplicatedReaders as unknown as T;
    }
    if (key === KEYS.USERS) {
      const users = parsed as User[];
      let modified = false;
      let overrides: Record<string, { password: string; passwordUpdatedAt: number }> = {};
      try {
        const rawOv = localStorage.getItem('twd_live_v4_password_overrides');
        if (rawOv) overrides = JSON.parse(rawOv) || {};
      } catch {}

      const applyOverride = (u: User): User => {
        const keysToCheck = [
          u.email ? u.email.trim().toLowerCase() : '',
          u.id ? u.id.trim().toLowerCase() : '',
          u.linkedAccountNumber ? u.linkedAccountNumber.trim().toLowerCase() : '',
        ].filter(Boolean);
        let bestPw = u.password;
        let bestTs = u.passwordUpdatedAt || 0;
        for (const k of keysToCheck) {
          const ov = overrides[k];
          if (ov && ov.password && ov.passwordUpdatedAt >= bestTs) {
            if (bestPw !== ov.password || bestTs !== ov.passwordUpdatedAt) {
              modified = true;
            }
            bestPw = ov.password;
            bestTs = ov.passwordUpdatedAt;
          }
        }
        return bestTs > 0 ? { ...u, password: bestPw, passwordUpdatedAt: bestTs } : { ...u, password: bestPw };
      };

      const mergeTwoUsers = (a: User, b: User): User => {
        const aReal = isRealIssuedAccountNumber(a.linkedAccountNumber);
        const bReal = isRealIssuedAccountNumber(b.linkedAccountNumber);
        const preferredId =
          a.id && !a.id.startsWith('email_')
            ? a.id
            : b.id && !b.id.startsWith('email_')
              ? b.id
              : a.id || b.id;
        const aPwTs = a.passwordUpdatedAt || 0;
        const bPwTs = b.passwordUpdatedAt || 0;
        const useBPw = bPwTs > aPwTs || (bPwTs === aPwTs && Boolean(b.password) && !a.password);
        const chosenPassword = useBPw ? b.password || a.password : a.password || b.password;
        const chosenPwTs = Math.max(aPwTs, bPwTs);
        return applyOverride({
          ...a,
          ...b,
          id: preferredId,
          email: (b.email || a.email || '').trim(),
          name: b.name || a.name,
          role: a.role === 'admin' || b.role === 'admin' ? 'admin' : b.role || a.role || 'consumer',
          status:
            aReal || bReal || a.status === 'active' || b.status === 'active'
              ? a.status === 'inactive' && b.status === 'inactive'
                ? 'inactive'
                : 'active'
              : b.status || a.status || 'pending_approval',
          linkedAccountNumber: bReal
            ? b.linkedAccountNumber!.trim().toUpperCase()
            : aReal
              ? a.linkedAccountNumber!.trim().toUpperCase()
              : b.linkedAccountNumber || a.linkedAccountNumber,
          password: chosenPassword,
          ...(chosenPwTs > 0 ? { passwordUpdatedAt: chosenPwTs } : {}),
        });
      };

      const deduplicatedUsers: User[] = [];
      users.forEach(rawU => {
        if (!rawU) return;
        if (isAccountTerminated(rawU)) {
          modified = true;
          return;
        }
        const u = applyOverride(rawU);
        const uEmail = (u.email || '').trim().toLowerCase();
        const uId = (u.id || '').trim().toLowerCase();
        const uUsername = (u.username || '').trim().toLowerCase();

        const existingIdx = deduplicatedUsers.findIndex(ex => {
          const exEmail = (ex.email || '').trim().toLowerCase();
          const exId = (ex.id || '').trim().toLowerCase();
          const exUsername = (ex.username || '').trim().toLowerCase();
          return (
            (uEmail && exEmail && uEmail === exEmail) ||
            (uId && exId && uId === exId) ||
            (uUsername && exUsername && uUsername === exUsername)
          );
        });

        if (existingIdx >= 0) {
          deduplicatedUsers[existingIdx] = mergeTwoUsers(deduplicatedUsers[existingIdx], u);
          modified = true;
        } else {
          deduplicatedUsers.push(u);
        }
      });

      if (deduplicatedUsers.length !== users.length) {
        modified = true;
      }
      deduplicatedUsers.forEach(u => {
        if (u.email && u.email.toLowerCase() === 'admin@tagoloanwater.gov.ph') {
          if (u.name !== 'Admin') {
            u.name = 'Admin';
            modified = true;
          }
          if (!u.password) {
            u.password = 'AdminWater2025!';
            modified = true;
          }
        }
        if (u.email && u.email.toLowerCase() === 'acero@gmail.com') {
          if (u.name !== 'Bruce Acero') {
            u.name = 'Bruce Acero';
            modified = true;
          }
          if (u.status !== 'active') {
            u.status = 'active';
            modified = true;
          }
        }
      });
      const hasMockUsers = deduplicatedUsers.some(u => u.email === 'john@example.com' || u.email === 'maria@example.com');
      const adminExists = deduplicatedUsers.some(u => u.email && u.email.toLowerCase() === 'admin@tagoloanwater.gov.ph');
      
      // Ensure essential baseline users exist (Admin + Acero demo account) only if NOT terminated
      INITIAL_USERS.forEach(iu => {
        if (!isAccountTerminated(iu) && !deduplicatedUsers.some(u => (iu.email && u.email?.toLowerCase() === iu.email.toLowerCase()) || (iu.id && u.id === iu.id))) {
          deduplicatedUsers.push(applyOverride(iu));
          modified = true;
        }
      });

      const cleanedUsers = deduplicatedUsers
        .filter(u => !isAccountTerminated(u) && u.email !== 'john@example.com' && u.email !== 'maria@example.com');
      if (!cleanedUsers.some(u => u.email && u.email.toLowerCase() === 'admin@tagoloanwater.gov.ph')) {
        cleanedUsers.unshift(INITIAL_USERS[0]);
      }
      cleanedUsers.sort(compareUsersCanonical);
      const nextUsersJson = JSON.stringify(cleanedUsers);
      if (hasMockUsers || !adminExists || modified || data !== nextUsersJson) {
        localStorage.setItem(key, nextUsersJson);
      }
      return cleanedUsers as unknown as T;
    }
    if (key === KEYS.BARANGAYS) {
      const brgs = Array.isArray(parsed) ? [...(parsed as Barangay[])] : [];
      const hasLegacyPoblacionEast = brgs.some(b => b.name === 'Poblacion East' || b.name === 'Poblacion West');
      if (hasLegacyPoblacionEast) {
        localStorage.setItem(key, JSON.stringify(INITIAL_BARANGAYS));
        return INITIAL_BARANGAYS as unknown as T;
      }
      const deletedBarangayIds = getDeletedBarangayIds();
      let brgChanged = false;
      for (let i = 0; i < brgs.length; i++) {
        if (brgs[i] && Number(brgs[i].ratePerM3) === 24.5) {
          brgs[i] = { ...brgs[i], ratePerM3: 10.00 };
          brgChanged = true;
        }
      }
      INITIAL_BARANGAYS.forEach((ib) => {
        if (deletedBarangayIds.has(ib.id)) return;
        const exists = brgs.some(
          (b) =>
            (b.id && b.id.toLowerCase() === ib.id.toLowerCase()) ||
            (b.name && b.name.trim().toLowerCase() === ib.name.trim().toLowerCase())
        );
        if (!exists) {
          brgs.push(ib);
          brgChanged = true;
        }
      });
      if (brgChanged) {
        localStorage.setItem(key, JSON.stringify(brgs));
        return brgs as unknown as T;
      }
    }
    if (key === KEYS.CONSUMERS) {
      let cons = parsed as Consumer[];
      const hasMockConsumers = cons.some(c => c.accountNumber === '1001-A' && c.name === 'John Doe');
      if (hasMockConsumers) {
        cons = cons.filter(c => c.accountNumber !== '1001-A' && c.accountNumber !== '1002-B' && c.accountNumber !== '1003-C');
      }
      // Ensure authentic baseline utility consumers exist without reverting issued accounts back to pending
      let changed = hasMockConsumers;
      let storedUsersList: User[] = [];
      try {
        const rawUsers = localStorage.getItem(KEYS.USERS);
        if (rawUsers) storedUsersList = JSON.parse(rawUsers) as User[];
      } catch {}

      cons = cons.map(c => {
        if (isRealIssuedAccountNumber(c.accountNumber)) {
          const norm = normalizeConsumerRecord(c);
          if (norm.status !== c.status || norm.accountNumber !== c.accountNumber || norm.meterNumber !== c.meterNumber) {
            changed = true;
          }
          return norm;
        }
        // Upgrade unissued consumer if matching user in localStorage already has an issued linkedAccountNumber
        const cEmail = (c.email || '').trim().toLowerCase();
        const cUid = (c.linkedUserId || '').trim();
        const matchedU = storedUsersList.find(
          u =>
            u.role !== 'admin' &&
            isRealIssuedAccountNumber(u.linkedAccountNumber) &&
            ((cEmail && u.email && u.email.trim().toLowerCase() === cEmail) || (cUid && u.id === cUid))
        );
        if (matchedU && matchedU.linkedAccountNumber) {
          changed = true;
          return normalizeConsumerRecord({
            ...c,
            accountNumber: matchedU.linkedAccountNumber,
            status: 'active',
          });
        }
        return c;
      });

      INITIAL_CONSUMERS.forEach(ic => {
        const exists = cons.some(c => 
          (ic.accountNumber && c.accountNumber === ic.accountNumber) ||
          (ic.email && c.email && c.email.toLowerCase() === ic.email.toLowerCase()) ||
          (ic.linkedUserId && c.linkedUserId && c.linkedUserId === ic.linkedUserId)
        );
        if (!exists) {
          cons.push(ic);
          changed = true;
        }
      });

      // Deduplicate stale pending placeholders if an active issued consumer record exists for the same email, userId, phone, or name
      const normPhone = (raw?: string) => {
        if (!raw) return '';
        let d = String(raw).replace(/\D/g, '');
        if (d.startsWith('63') && d.length === 12) d = '0' + d.slice(2);
        if (d.length === 10 && d.startsWith('9')) d = '0' + d;
        return d;
      };
      const isIssuedRec = (c: Consumer) => isRealIssuedAccountNumber(c.accountNumber);
      const beforeLen = cons.length;
      cons = cons.filter((c, _idx, arr) => {
        if (isIssuedRec(c)) return true;
        const cEmail = (c.email || '').trim().toLowerCase();
        const cUid = (c.linkedUserId || '').trim();
        const cPhone = normPhone(c.contactNumber);
        const cName = (c.name || '').trim().toLowerCase();
        const activeTwin = arr.find(o => {
          if (o === c || !isIssuedRec(o)) return false;
          const oEmail = (o.email || '').trim().toLowerCase();
          const oUid = (o.linkedUserId || '').trim();
          const oPhone = normPhone(o.contactNumber);
          const oName = (o.name || '').trim().toLowerCase();
          if (cEmail && oEmail && cEmail === oEmail) return true;
          if (cUid && oUid && cUid === oUid) return true;
          if (cPhone && oPhone && cPhone.length === 11 && cPhone === oPhone) return true;
          if (cName && oName && cName === oName && (!cEmail || !oEmail || cEmail === oEmail)) return true;
          return false;
        });
        if (activeTwin) {
          if (!activeTwin.email && c.email) activeTwin.email = c.email;
          if (!activeTwin.linkedUserId && c.linkedUserId) activeTwin.linkedUserId = c.linkedUserId;
          if (!activeTwin.contactNumber && c.contactNumber) activeTwin.contactNumber = c.contactNumber;
          return false;
        }
        return true;
      });
      if (cons.length !== beforeLen) {
        changed = true;
      }

      cons.sort(compareConsumersCanonical);
      const nextConsJson = JSON.stringify(cons);
      if (changed || data !== nextConsJson) {
        localStorage.setItem(key, nextConsJson);
      }
      return cons as unknown as T;
    }
    if (key === KEYS.METERS) {
      let meters = parsed as WaterMeter[];
      INITIAL_METERS.forEach(im => {
        if (!meters.some(m => m.meterNumber === im.meterNumber)) {
          meters.push(im);
        }
      });
      meters = meters.map((m) => ensureMeterSerialNumber(m)).sort(compareMetersCanonical);
      const nextMetersJson = JSON.stringify(meters);
      if (data !== nextMetersJson) {
        localStorage.setItem(key, nextMetersJson);
      }
      return meters as unknown as T;
    }
    if (key === KEYS.READINGS) {
      let reads = parsed as MeterReading[];
      const hasMockReads = reads.some(r => r.id.startsWith('R-1001-A') || r.id.startsWith('R-1002-B'));
      if (hasMockReads) {
        reads = reads.filter(r => !r.id.startsWith('R-1001-A') && !r.id.startsWith('R-1002-B'));
      }

      // Migrate any old pending Acero readings to Bruce Acero with BRG-01-3117
      reads.forEach(r => {
        if (r.id === 'R-PENDING-ACERO-202608' || r.accountNumber === 'PENDING-ACERO' || r.consumerName === 'ACERO, MARIEL S.') {
          r.id = 'R-BRG-01-3117-202608';
          r.accountNumber = 'BRG-01-3117';
          r.consumerName = 'Bruce Acero';
          r.meterNumber = '150309988';
          r.meterBrand = 'EVER';
          r.route = 'Poblacion Zone 3 Route';
        }
      });

      INITIAL_READINGS.forEach(ir => {
        const alreadyExists = reads.some(r => r.id === ir.id || (r.consumerName.trim().toLowerCase() === ir.consumerName.trim().toLowerCase() && r.billingPeriod === ir.billingPeriod));
        if (!alreadyExists) {
          reads.push(ir);
        }
      });

      // Synchronize reading account numbers if consumer was assigned official IDs
      try {
        const storedConsumers = localStorage.getItem(KEYS.CONSUMERS);
        if (storedConsumers) {
          const consumersList = JSON.parse(storedConsumers) as Consumer[];
          reads = reads.map(r => {
            const matchedConsumer = consumersList.find(c => 
              (c.accountNumber && c.accountNumber === r.accountNumber) ||
              (c.name && c.name.trim().toLowerCase() === r.consumerName.trim().toLowerCase())
            );
            if (matchedConsumer && matchedConsumer.accountNumber && matchedConsumer.accountNumber !== r.accountNumber && !matchedConsumer.accountNumber.toUpperCase().startsWith('PENDING')) {
              return {
                ...r,
                accountNumber: matchedConsumer.accountNumber,
                meterNumber: matchedConsumer.meterNumber || r.meterNumber,
                meterBrand: matchedConsumer.meterBrand || r.meterBrand
              };
            }
            return r;
          });
        }
      } catch {}

      reads = reads.map(r => normalizeReadingToOfficialBaseline(r)).sort(compareReadingsCanonical);
      const nextReadsJson = JSON.stringify(reads);
      if (data !== nextReadsJson) {
        localStorage.setItem(key, nextReadsJson);
      }
      return reads as unknown as T;
    }
    return parsed;
  } catch (e) {
    return initial;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    const json = JSON.stringify(value);
    const existing = localStorage.getItem(key);
    if (existing === json) {
      return; // Data has not changed, do not trigger event loops
    }
    localStorage.setItem(key, json);
    if (typeof window !== 'undefined') {
      // Notify mounted components in same window immediately
      window.dispatchEvent(new CustomEvent('twd_database_updated', { detail: { key, timestamp: Date.now() } }));
      // Cross-tab synchronization ping
      try {
        localStorage.setItem('twd_sync_ping', `${Date.now()}_${key}`);
      } catch {}
    }
  } catch (e) {
    console.warn(`[mockDb] Error persisting key "${key}":`, e);
  }
}

const DELETED_ANNOUNCEMENTS_KEY = 'twd_live_v4_deleted_announcements';
const DELETED_BARANGAYS_KEY = 'twd_live_v4_deleted_barangays';
const READ_BROADCAST_NOTIFS_KEY = 'twd_live_v4_read_broadcast_notifs';

function getDeletedBarangayIds(): Set<string> {
  try {
    const raw = localStorage.getItem(DELETED_BARANGAYS_KEY);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

function addDeletedBarangayId(id: string): void {
  try {
    const set = getDeletedBarangayIds();
    set.add(id);
    localStorage.setItem(DELETED_BARANGAYS_KEY, JSON.stringify(Array.from(set)));
  } catch {}
}

function getDeletedAnnouncementIds(): Set<string> {
  try {
    const raw = localStorage.getItem(DELETED_ANNOUNCEMENTS_KEY);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

function addDeletedAnnouncementId(id: string): void {
  try {
    const set = getDeletedAnnouncementIds();
    set.add(id);
    localStorage.setItem(DELETED_ANNOUNCEMENTS_KEY, JSON.stringify(Array.from(set)));
  } catch {}
}

function getReadBroadcastNotifSet(): Set<string> {
  try {
    const raw = localStorage.getItem(READ_BROADCAST_NOTIFS_KEY);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

function markBroadcastNotifReadForIdentity(notifId: string, identityKey: string): void {
  try {
    const set = getReadBroadcastNotifSet();
    set.add(`${identityKey}::${notifId}`);
    localStorage.setItem(READ_BROADCAST_NOTIFS_KEY, JSON.stringify(Array.from(set)));
  } catch {}
}

/**
 * Computes strictly the subset of items in `nextItems` whose serialized JSON changed
 * compared to what is currently stored in `localStorage[key]`, preventing full-collection
 * Firestore batch writes on minor updates.
 */
function diffChangedItems<T extends Record<string, any>>(key: string, nextItems: T[], idField: string): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return nextItems;
    const prevItems = JSON.parse(raw) as T[];
    if (!Array.isArray(prevItems)) return nextItems;
    const prevMap = new Map<string, string>();
    prevItems.forEach((item) => {
      const k = String(item?.[idField] || item?.id || item?.accountNumber || item?.email || '');
      if (k) prevMap.set(k, JSON.stringify(item));
    });
    return nextItems.filter((item) => {
      const k = String(item?.[idField] || item?.id || item?.accountNumber || item?.email || '');
      if (!k) return true;
      return prevMap.get(k) !== JSON.stringify(item);
    });
  } catch {
    return nextItems;
  }
}

export const mockDb = {
  // Get all datasets
  getUsers: (): User[] => [...getStored<User[]>(KEYS.USERS, INITIAL_USERS)].sort(compareUsersCanonical),
  getConsumers: (): Consumer[] => [...getStored<Consumer[]>(KEYS.CONSUMERS, INITIAL_CONSUMERS)].sort(compareConsumersCanonical),
  getReaders: (): MeterReader[] => [...getStored<MeterReader[]>(KEYS.READERS, INITIAL_READERS)].sort(compareReadersCanonical),
  getMeters: (): WaterMeter[] => getStored<WaterMeter[]>(KEYS.METERS, INITIAL_METERS).map(ensureMeterSerialNumber).sort(compareMetersCanonical),
  getReadings: (): MeterReading[] => [...getStored<MeterReading[]>(KEYS.READINGS, INITIAL_READINGS)].sort(compareReadingsCanonical),
  getRoutes: (): RouteAssignment[] => [...getStored<RouteAssignment[]>(KEYS.ROUTES, INITIAL_ROUTES)].sort(compareRoutesCanonical),
  getAnnouncements: (): Announcement[] => {
    const deleted = getDeletedAnnouncementIds();
    const raw = getStored<Announcement[]>(KEYS.ANNOUNCEMENTS, INITIAL_ANNOUNCEMENTS).filter(
      (a) => a && (!a.id || !deleted.has(a.id))
    );
    return sanitizeAnnouncements(raw).sort(compareAnnouncementsCanonical);
  },
  getAuditLogs: (): AuditLog[] => [...getStored<AuditLog[]>(KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS)].sort(compareAuditLogsCanonical),
  getBarangays: (): Barangay[] => [...getStored<Barangay[]>(KEYS.BARANGAYS, INITIAL_BARANGAYS)].sort(compareBarangaysCanonical),
  getCurrentUser: (): User | null => {
    try {
      const u = localStorage.getItem(KEYS.CURRENT_USER);
      if (!u) return null;
      const user = JSON.parse(u) as User;
      if (user && user.email && user.email.toLowerCase() === 'admin@tagoloanwater.gov.ph') {
        if (user.name !== 'Admin') {
          user.name = 'Admin';
          localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(user));
        }
      }
      try {
        const rawOv = localStorage.getItem('twd_live_v4_password_overrides');
        if (rawOv) {
          const ovMap = JSON.parse(rawOv) || {};
          const keys = [
            user.email ? user.email.trim().toLowerCase() : '',
            user.id ? user.id.trim().toLowerCase() : '',
            user.linkedAccountNumber ? user.linkedAccountNumber.trim().toLowerCase() : '',
          ].filter(Boolean);
          for (const k of keys) {
            const ov = ovMap[k];
            if (ov && ov.password && ov.passwordUpdatedAt >= (user.passwordUpdatedAt || 0)) {
              user.password = ov.password;
              user.passwordUpdatedAt = ov.passwordUpdatedAt;
            }
          }
        }
      } catch {}
      return user;
    } catch {
      return null;
    }
  },

  // State Updates
  setCurrentUser: (user: User | null): void => {
    try {
      const prevRaw = localStorage.getItem(KEYS.CURRENT_USER);
      if (user) {
        const nextJson = JSON.stringify(user);
        if (prevRaw === nextJson) return;
        localStorage.setItem(KEYS.CURRENT_USER, nextJson);
      } else {
        if (prevRaw === null) return;
        localStorage.removeItem(KEYS.CURRENT_USER);
      }
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('twd_database_updated', { detail: { key: KEYS.CURRENT_USER, timestamp: Date.now() } }));
        try {
          localStorage.setItem('twd_sync_ping', `${Date.now()}_${KEYS.CURRENT_USER}`);
        } catch {}
      }
    } catch {}
  },

  saveUsers: (users: User[]): void => {
    const sorted = [...users].sort(compareUsersCanonical);
    const changed = diffChangedItems(KEYS.USERS, sorted, 'id');
    setStored(KEYS.USERS, sorted);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.USERS, changed, 'id');
  },

  updateUserPassword: (
    identity: { userId?: string; email?: string; accountNumber?: string },
    newPassword: string,
    passwordUpdatedAt?: number
  ): User | null => {
    const ts = passwordUpdatedAt || Date.now();
    const cleanEmail = (identity.email || '').trim().toLowerCase();
    const cleanId = (identity.userId || '').trim();
    const cleanAcc = (identity.accountNumber || '').trim().toUpperCase();

    // 1. Persist authoritative local override so stale cloud/seed snapshots can never revert the password
    try {
      const rawOv = localStorage.getItem('twd_live_v4_password_overrides');
      const ovMap: Record<string, { password: string; passwordUpdatedAt: number }> = rawOv ? JSON.parse(rawOv) : {};
      if (cleanEmail) ovMap[cleanEmail] = { password: newPassword, passwordUpdatedAt: ts };
      if (cleanId) ovMap[cleanId.toLowerCase()] = { password: newPassword, passwordUpdatedAt: ts };
      if (cleanAcc && !cleanAcc.startsWith('PENDING')) {
        ovMap[cleanAcc.toLowerCase()] = { password: newPassword, passwordUpdatedAt: ts };
      }
      localStorage.setItem('twd_live_v4_password_overrides', JSON.stringify(ovMap));
    } catch {}

    // 2. Update ALL matching user records in localStorage KEYS.USERS
    const allUsers = getStored<User[]>(KEYS.USERS, INITIAL_USERS);
    let primaryUpdated: User | null = null;
    const nextUsers = allUsers.map((u) => {
      const uEmail = (u.email || '').trim().toLowerCase();
      const uAcc = (u.linkedAccountNumber || '').trim().toUpperCase();
      const matches =
        (cleanId && u.id === cleanId) ||
        (cleanEmail && uEmail && uEmail === cleanEmail) ||
        (cleanAcc && !cleanAcc.startsWith('PENDING') && uAcc === cleanAcc);
      if (!matches) return u;
      const updatedUser: User = {
        ...u,
        password: newPassword,
        passwordUpdatedAt: ts,
      };
      if (!primaryUpdated || !u.id.startsWith('email_')) {
        primaryUpdated = updatedUser;
      }
      return updatedUser;
    });

    if (!primaryUpdated && (cleanEmail || cleanId)) {
      primaryUpdated = {
        id: cleanId || `user-${ts}`,
        email: cleanEmail,
        name: cleanEmail.split('@')[0] || 'Consumer',
        role: 'consumer',
        status: cleanAcc && !cleanAcc.startsWith('PENDING') ? 'active' : 'pending_approval',
        linkedAccountNumber: cleanAcc || undefined,
        password: newPassword,
        passwordUpdatedAt: ts,
      };
      nextUsers.unshift(primaryUpdated);
    }

    setStored(KEYS.USERS, nextUsers);

    // 3. Update active session user if matching
    const cur = mockDb.getCurrentUser();
    if (cur) {
      const curEmail = (cur.email || '').trim().toLowerCase();
      const curAcc = (cur.linkedAccountNumber || '').trim().toUpperCase();
      if (
        (cleanId && cur.id === cleanId) ||
        (cleanEmail && curEmail === cleanEmail) ||
        (cleanAcc && !cleanAcc.startsWith('PENDING') && curAcc === cleanAcc)
      ) {
        mockDb.setCurrentUser({
          ...cur,
          password: newPassword,
          passwordUpdatedAt: ts,
        });
      }
    }

    // 4. Sync BOTH primary ID doc and email_ doc in Firestore so resolve-account never reads an outdated twin
    if (primaryUpdated) {
      const targetUser = primaryUpdated as User;
      if (targetUser.id) {
        syncDocToFirestore(COLLECTIONS.USERS, targetUser.id, targetUser, true);
      }
      const emailForDoc = (targetUser.email || cleanEmail || '').trim().toLowerCase();
      if (emailForDoc) {
        const emailDocKey = `email_${emailForDoc.replace(/[^a-zA-Z0-9_-]/g, '_')}`.slice(0, 120);
        syncDocToFirestore(COLLECTIONS.USERS, emailDocKey, targetUser, true);
      }
    }

    return primaryUpdated;
  },
  saveConsumers: (consumers: Consumer[]): void => {
    const normalizedList = consumers.map(c => normalizeConsumerRecord(c));
    // Deduplicate consumers: if an issued record exists, drop stale pending placeholders for same user/email/phone/name
    const deduplicated = normalizedList.filter((c, _idx, arr) => {
      const isPending = !isRealIssuedAccountNumber(c.accountNumber) || isPendingConsumerStatus(c.status);
      if (isPending) {
        const hasActiveTwin = arr.some(o => o !== c && isRealIssuedAccountNumber(o.accountNumber) && (
          (c.linkedUserId && o.linkedUserId && o.linkedUserId === c.linkedUserId) ||
          (c.email && o.email && o.email.toLowerCase() === c.email.toLowerCase()) ||
          (c.name && o.name && o.name.toLowerCase() === c.name.toLowerCase() && (!c.email || !o.email || c.email.toLowerCase() === o.email.toLowerCase()) && (!c.barangay || !o.barangay || c.barangay.toLowerCase() === o.barangay.toLowerCase()))
        ));
        if (hasActiveTwin) return false;
      }
      return true;
    });

    deduplicated.sort(compareConsumersCanonical);
    const changed = diffChangedItems(KEYS.CONSUMERS, deduplicated, 'accountNumber');
    setStored(KEYS.CONSUMERS, deduplicated);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.CONSUMERS, changed, 'accountNumber');
  },
  saveReaders: (readers: MeterReader[]): void => {
    const seen = new Set<string>();
    const deduplicated: MeterReader[] = [];
    readers.forEach(r => {
      if (isAccountTerminated(r)) return; // Never save terminated accounts
      const kId = (r.id || '').trim().toLowerCase();
      const kEmp = (r.employeeId || '').trim().toLowerCase();
      const kUser = (r.username || '').trim().toLowerCase();
      const kName = (r.name || '').trim().toLowerCase();
      const kEmail = (r.email || '').trim().toLowerCase();

      if (
        (kId && seen.has(kId)) ||
        (kEmp && seen.has(kEmp)) ||
        (kUser && seen.has(kUser)) ||
        (kName && seen.has(kName)) ||
        (kEmail && seen.has(kEmail))
      ) {
        return;
      }

      if (kId) seen.add(kId);
      if (kEmp) seen.add(kEmp);
      if (kUser) seen.add(kUser);
      if (kName) seen.add(kName);
      if (kEmail) seen.add(kEmail);
      deduplicated.push(r);
    });
    deduplicated.sort(compareReadersCanonical);
    const changed = diffChangedItems(KEYS.READERS, deduplicated, 'id');
    setStored(KEYS.READERS, deduplicated);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.READERS, changed, 'id');
  },
  deleteReader: (readerId: string, employeeId?: string, email?: string, username?: string, name?: string): void => {
    // 1. Mark identifiers in blacklist
    addTerminatedAccountKeys([readerId, employeeId, email, username, name]);

    // 2. Remove from local READERS
    const currentReaders = getStored<MeterReader[]>(KEYS.READERS, INITIAL_READERS);
    const updatedReaders = currentReaders.filter(r => 
      !isAccountTerminated(r) &&
      r.id !== readerId && 
      (!employeeId || r.employeeId !== employeeId) && 
      (!email || !r.email || r.email.toLowerCase() !== email.toLowerCase()) &&
      (!username || !r.username || r.username.toLowerCase() !== username.toLowerCase()) &&
      (!name || r.name.toLowerCase() !== name.toLowerCase())
    );
    setStored(KEYS.READERS, updatedReaders);

    // 3. Remove from local USERS
    const allUsers = getStored<User[]>(KEYS.USERS, INITIAL_USERS);
    const updatedUsers = allUsers.filter(u => 
      !isAccountTerminated(u) &&
      u.id !== readerId && 
      (!employeeId || u.employeeId !== employeeId) && 
      (!email || !u.email || u.email.toLowerCase() !== email.toLowerCase()) &&
      (!username || !u.username || u.username.toLowerCase() !== username.toLowerCase()) &&
      (!name || u.name.toLowerCase() !== name.toLowerCase())
    );
    setStored(KEYS.USERS, updatedUsers);

    // 4. Clear any route assignments for this reader
    const currentRoutes = getStored<RouteAssignment[]>(KEYS.ROUTES, INITIAL_ROUTES);
    const updatedRoutes = currentRoutes.map(rt => {
      if (rt.assignedReaderId === readerId || (employeeId && rt.assignedReaderId === employeeId) || (name && rt.assignedReaderName === name)) {
        return {
          ...rt,
          assignedReaderId: '',
          assignedReaderName: '',
          status: 'pending' as const
        };
      }
      return rt;
    });
    setStored(KEYS.ROUTES, updatedRoutes);

    // 5. If current active user in session is this reader, log them out
    const currentUser = mockDb.getCurrentUser();
    if (currentUser && (
      currentUser.id === readerId || 
      (employeeId && currentUser.employeeId === employeeId) || 
      (email && currentUser.email?.toLowerCase() === email.toLowerCase()) ||
      (username && currentUser.username?.toLowerCase() === username.toLowerCase())
    )) {
      mockDb.setCurrentUser(null);
    }

    // 6. Deep erasure across Firestore (documents and queries)
    eraseAccountFromFirestore({
      id: readerId,
      employeeId,
      email,
      username,
      name
    });
  },

  deleteUser: (userId: string, email?: string, username?: string, name?: string): void => {
    addTerminatedAccountKeys([userId, email, username, name]);
    const allUsers = getStored<User[]>(KEYS.USERS, INITIAL_USERS);
    const updatedUsers = allUsers.filter(u => 
      !isAccountTerminated(u) &&
      u.id !== userId &&
      (!email || !u.email || u.email.toLowerCase() !== email.toLowerCase()) &&
      (!username || !u.username || u.username.toLowerCase() !== username.toLowerCase()) &&
      (!name || u.name.toLowerCase() !== name.toLowerCase())
    );
    setStored(KEYS.USERS, updatedUsers);
    eraseAccountFromFirestore({ id: userId, email, username, name });
  },

  deleteConsumer: (accountNumber?: string, email?: string, linkedUserId?: string, name?: string): void => {
    // 1. Add keys to blacklist
    addTerminatedAccountKeys([accountNumber, email, linkedUserId, name]);

    // 2. Erase from CONSUMERS
    const allConsumers = getStored<Consumer[]>(KEYS.CONSUMERS, INITIAL_CONSUMERS);
    const updatedConsumers = allConsumers.filter(c => 
      !isAccountTerminated(c) &&
      (!accountNumber || c.accountNumber !== accountNumber) &&
      (!email || !c.email || c.email.toLowerCase() !== email.toLowerCase()) &&
      (!linkedUserId || c.linkedUserId !== linkedUserId) &&
      (!name || c.name.toLowerCase() !== name.toLowerCase())
    );
    setStored(KEYS.CONSUMERS, updatedConsumers);

    // 3. Delete linked user account if exists
    mockDb.deleteUser(linkedUserId || '', email, undefined, name);

    // 4. Unassign any water meters linked to this consumer
    if (accountNumber) {
      const allMeters = getStored<WaterMeter[]>(KEYS.METERS, INITIAL_METERS);
      const updatedMeters = allMeters.map(m => {
        if (m.linkedAccountNumber === accountNumber) {
          return { ...m, linkedAccountNumber: '' };
        }
        return m;
      });
      setStored(KEYS.METERS, updatedMeters);
    }

    // 5. Erase from Firestore
    const docId = accountNumber || linkedUserId || (email ? `email_${email.toLowerCase().replace(/[^a-zA-Z0-9_-]/g, '_')}` : '');
    if (docId) {
      deleteDocFromFirestore(COLLECTIONS.CONSUMERS, docId);
    }
    eraseAccountFromFirestore({ id: linkedUserId || accountNumber, email, name });
  },

  deleteMeter: (meterNumber: string): void => {
    const allMeters = getStored<WaterMeter[]>(KEYS.METERS, INITIAL_METERS);
    const updatedMeters = allMeters.filter(m => m.meterNumber !== meterNumber);
    setStored(KEYS.METERS, updatedMeters);

    // Unlink any consumer linked to this meter
    const allConsumers = getStored<Consumer[]>(KEYS.CONSUMERS, INITIAL_CONSUMERS);
    const updatedConsumers = allConsumers.map(c => {
      if (c.meterNumber === meterNumber) {
        return { ...c, meterNumber: 'UNASSIGNED' };
      }
      return c;
    });
    setStored(KEYS.CONSUMERS, updatedConsumers);

    deleteDocFromFirestore(COLLECTIONS.METERS, meterNumber);
  },

  deleteReading: (readingId: string): void => {
    const allReadings = getStored<MeterReading[]>(KEYS.READINGS, INITIAL_READINGS);
    const updatedReadings = allReadings.filter(r => r.id !== readingId);
    setStored(KEYS.READINGS, updatedReadings);
    deleteDocFromFirestore(COLLECTIONS.READINGS, readingId);
  },

  deleteAnnouncement: (id: string): void => {
    addDeletedAnnouncementId(id);
    const allAnnouncements = getStored<Announcement[]>(KEYS.ANNOUNCEMENTS, INITIAL_ANNOUNCEMENTS);
    const updatedAnnouncements = allAnnouncements.filter(a => a.id !== id);
    setStored(KEYS.ANNOUNCEMENTS, updatedAnnouncements);
    deleteDocFromFirestore(COLLECTIONS.ANNOUNCEMENTS, id);
    safeBackendFetch(`/api/announcements/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
  },

  deleteBarangay: (id: string): void => {
    addDeletedBarangayId(id);
    const allBarangays = getStored<Barangay[]>(KEYS.BARANGAYS, INITIAL_BARANGAYS);
    const updatedBarangays = allBarangays.filter(b => b.id !== id);
    setStored(KEYS.BARANGAYS, updatedBarangays);
    deleteDocFromFirestore(COLLECTIONS.BARANGAYS, id);
  },

  saveMeters: (meters: WaterMeter[]): void => {
    const sorted = meters.map(ensureMeterSerialNumber).sort(compareMetersCanonical);
    const changed = diffChangedItems(KEYS.METERS, sorted, 'meterNumber');
    setStored(KEYS.METERS, sorted);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.METERS, changed, 'meterNumber');
  },
  saveMeterAsync: async (updatedMeter: WaterMeter, previousMeterNumber?: string): Promise<WaterMeter[]> => {
    const currentMeters = getStored<WaterMeter[]>(KEYS.METERS, INITIAL_METERS);
    const normalizedUpdated = ensureMeterSerialNumber(updatedMeter);
    const targetPrevNum = (previousMeterNumber || normalizedUpdated.meterNumber || '').trim();
    const existingIdx = currentMeters.findIndex(
      (m) => m.meterNumber.trim().toLowerCase() === targetPrevNum.toLowerCase()
    );
    let nextMeters: WaterMeter[];
    if (existingIdx >= 0) {
      nextMeters = currentMeters.map((m, idx) => (idx === existingIdx ? normalizedUpdated : m));
    } else {
      nextMeters = [normalizedUpdated, ...currentMeters];
    }
    nextMeters = nextMeters.map(ensureMeterSerialNumber).sort(compareMetersCanonical);
    setStored(KEYS.METERS, nextMeters);
    if (previousMeterNumber && previousMeterNumber.trim() !== normalizedUpdated.meterNumber.trim()) {
      deleteDocFromFirestore(COLLECTIONS.METERS, previousMeterNumber.trim());
    }
    await syncDocToFirestore(
      COLLECTIONS.METERS,
      normalizedUpdated.meterNumber,
      normalizedUpdated as unknown as Record<string, unknown>,
      true
    );
    return nextMeters;
  },
  saveReadings: (readings: MeterReading[]): void => {
    const normalized = readings
      .map(r => {
        const odo = computeOdometerConsumption(
          r.previousReading,
          r.currentReading ?? r.presentReading,
          r.consumption
        );
        return normalizeReadingToOfficialBaseline({
          ...r,
          previousReading: odo.previousReading,
          presentReading: odo.currentReading,
          currentReading: odo.currentReading,
          consumption: odo.consumption,
        });
      })
      .sort(compareReadingsCanonical);
    const changed = diffChangedItems(KEYS.READINGS, normalized, 'id');
    setStored(KEYS.READINGS, normalized);
    if (changed.length > 0) {
      syncBatchToFirestore(COLLECTIONS.READINGS, changed, 'id');
      safeBackendFetch('/api/billings/reconcile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ readings: changed }),
      }).catch(() => {});
    }
  },
  mergeExternalReadings: (incoming: MeterReading[]): MeterReading[] => {
    const localList = mockDb.getReadings();
    if (!Array.isArray(incoming) || incoming.length === 0) return localList;
    const map = new Map<string, MeterReading>();
    localList.forEach(lr => {
      if (lr?.id) map.set(lr.id, lr);
    });
    let changed = false;
    incoming.forEach(ir => {
      if (!ir?.id) return;
      const prev = map.get(ir.id);
      if (!prev) {
        const odo = computeOdometerConsumption(
          ir.previousReading,
          ir.currentReading ?? ir.presentReading,
          ir.consumption
        );
        map.set(ir.id, normalizeReadingToOfficialBaseline({
          ...ir,
          previousReading: odo.previousReading,
          presentReading: odo.currentReading,
          currentReading: odo.currentReading,
          consumption: odo.consumption,
        }));
        changed = true;
        return;
      }
      const isPaid = prev.paymentStatus === 'paid' || ir.paymentStatus === 'paid';
      const isPartial = !isPaid && (prev.paymentStatus === 'partial' || ir.paymentStatus === 'partial');
      const prevBilled = Boolean(prev.isBillingIssued || prev.billingIssuedAt || prev.invoiceNumber || prev.paymentStatus === 'paid' || prev.paymentStatus === 'partial');
      const irBilled = Boolean(ir.isBillingIssued || ir.billingIssuedAt || ir.invoiceNumber || ir.paymentStatus === 'paid' || ir.paymentStatus === 'partial');
      const mergedBillingIssued = prevBilled || irBilled;
      const billedSource = irBilled ? ir : prevBilled ? prev : ir;
      const fallbackBilled = irBilled ? prev : ir;
      const maxPaid = Math.max(Number(prev.paidAmount || 0), Number(ir.paidAmount || 0));
      const mergedBillAmount = Number(billedSource.billAmount || fallbackBilled.billAmount || 0) || prev.billAmount || ir.billAmount;
      const mergedTotalAmount = Number(billedSource.totalAmount || fallbackBilled.totalAmount || mergedBillAmount || 0) || prev.totalAmount || ir.totalAmount;
      const computedRemaining = isPaid
        ? 0
        : isPartial
          ? Math.max(0, Number(mergedTotalAmount || mergedBillAmount || 0) - maxPaid)
          : (typeof billedSource.remainingBalance === 'number'
              ? billedSource.remainingBalance
              : typeof fallbackBilled.remainingBalance === 'number'
                ? fallbackBilled.remainingBalance
                : mergedTotalAmount);

      const rawCurr = billedSource.currentReading ?? billedSource.presentReading ?? fallbackBilled.currentReading ?? fallbackBilled.presentReading ?? 0;
      const candPrev = billedSource.previousReading ?? fallbackBilled.previousReading ?? 0;
      const odoMerged = computeOdometerConsumption(
        candPrev,
        rawCurr,
        billedSource.consumption ?? fallbackBilled.consumption
      );

      const next: MeterReading = {
        ...prev,
        ...ir,
        previousReading: odoMerged.previousReading,
        presentReading: odoMerged.currentReading,
        currentReading: odoMerged.currentReading,
        consumption: odoMerged.consumption,
        submittedAt: ir.submittedAt || prev.submittedAt,
        isBillingIssued: mergedBillingIssued ? true : Boolean(ir.isBillingIssued ?? prev.isBillingIssued),
        billingIssuedAt: ir.billingIssuedAt || prev.billingIssuedAt,
        billingIssuedBy: ir.billingIssuedBy || prev.billingIssuedBy,
        invoiceNumber: ir.invoiceNumber || prev.invoiceNumber,
        dueDate: billedSource.dueDate || fallbackBilled.dueDate,
        billAmount: mergedBillAmount,
        totalAmount: mergedTotalAmount,
        franchiseTax: billedSource.franchiseTax ?? fallbackBilled.franchiseTax,
        arrears: billedSource.arrears ?? fallbackBilled.arrears,
        penaltyAmount: billedSource.penaltyAmount ?? fallbackBilled.penaltyAmount,
        amountAfterDueDate: billedSource.amountAfterDueDate ?? fallbackBilled.amountAfterDueDate,
        status:
          prev.status === 'cancelled' || ir.status === 'cancelled'
            ? 'cancelled'
            : mergedBillingIssued || prev.status === 'verified' || ir.status === 'verified'
              ? 'verified'
              : (ir.status || prev.status),
        paymentStatus: isPaid ? 'paid' : isPartial ? 'partial' : (ir.paymentStatus || prev.paymentStatus),
        paidAmount: maxPaid > 0 ? maxPaid : (prev.paidAmount ?? ir.paidAmount),
        remainingBalance: computedRemaining,
        orNumber: ir.orNumber || prev.orNumber,
        paymentDate: ir.paymentDate || prev.paymentDate,
        paymentMethod: ir.paymentMethod || prev.paymentMethod,
        cashierName: ir.cashierName || prev.cashierName,
        transactionId: ir.transactionId || prev.transactionId,
        paymentReceiptUrl: ir.paymentReceiptUrl || prev.paymentReceiptUrl,
      };
      const normalizedNext = normalizeReadingToOfficialBaseline(next);
      if (JSON.stringify(prev) !== JSON.stringify(normalizedNext)) {
        map.set(ir.id, normalizedNext);
        changed = true;
      }
    });
    const merged = Array.from(map.values()).sort(compareReadingsCanonical);
    setStored(KEYS.READINGS, merged);
    return merged;
  },
  saveRoutes: (routes: RouteAssignment[]): void => {
    const sorted = [...routes].sort(compareRoutesCanonical);
    const changed = diffChangedItems(KEYS.ROUTES, sorted, 'id');
    setStored(KEYS.ROUTES, sorted);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.ROUTES, changed, 'id');
  },
  saveAnnouncements: (anns: Announcement[]): void => {
    const deleted = getDeletedAnnouncementIds();
    const filtered = sanitizeAnnouncements(anns.filter(a => a && (!a.id || !deleted.has(a.id)))).sort(compareAnnouncementsCanonical);
    const changed = diffChangedItems(KEYS.ANNOUNCEMENTS, filtered, 'id');
    setStored(KEYS.ANNOUNCEMENTS, filtered);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.ANNOUNCEMENTS, changed, 'id');
  },
  mergeExternalAnnouncements: (incoming: Announcement[]): Announcement[] => {
    const deleted = getDeletedAnnouncementIds();
    const localList = mockDb.getAnnouncements();
    const cleanIncoming = sanitizeAnnouncements(incoming);
    if (cleanIncoming.length === 0) return localList;
    const map = new Map<string, Announcement>();
    localList.forEach(la => {
      if (la?.id && !deleted.has(la.id)) map.set(la.id, la);
    });
    cleanIncoming.forEach(ia => {
      if (ia?.id && !deleted.has(ia.id)) {
        const prev = map.get(ia.id);
        map.set(ia.id, prev ? { ...prev, ...ia } : ia);
      }
    });
    const merged = sanitizeAnnouncements(Array.from(map.values())).sort(compareAnnouncementsCanonical);
    setStored(KEYS.ANNOUNCEMENTS, merged);
    return merged;
  },
  saveAuditLogs: (logs: AuditLog[]): void => {
    const sorted = [...logs].sort(compareAuditLogsCanonical);
    const recent = sorted.slice(0, 5);
    const changed = diffChangedItems(KEYS.AUDIT_LOGS, recent, 'id');
    setStored(KEYS.AUDIT_LOGS, sorted);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.AUDIT_LOGS, changed, 'id');
  },
  saveBarangays: (barangays: Barangay[]): void => {
    const sorted = [...barangays].sort(compareBarangaysCanonical);
    const changed = diffChangedItems(KEYS.BARANGAYS, sorted, 'id');
    setStored(KEYS.BARANGAYS, sorted);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.BARANGAYS, changed, 'id');
  },

  findOrCreateBarangay: (barangayName: string): Barangay => {
    const list = mockDb.getBarangays();
    const cleanName = barangayName.trim();
    const existing = list.find(b => (b.name || '').toLowerCase() === cleanName.toLowerCase());
    if (existing) {
      return existing;
    }
    const nextNum = list.length + 1;
    const generatedId = `BRG-${String(nextNum).padStart(2, '0')}`;
    const codePrefix = cleanName.replace(/[^a-zA-Z]/g, '').substring(0, 2).toUpperCase() || 'BG';
    const generatedCode = `${codePrefix}-${String(nextNum).padStart(2, '0')}`;
    
    const newBarangay: Barangay = {
      id: generatedId,
      name: cleanName,
      code: generatedCode,
      consumers: 1,
      activeMeters: 1,
      schedule: '1st - 15th of Month',
      supervisor: 'District Operations Supervisor',
      ratePerM3: 10.00
    };
    
    list.push(newBarangay);
    mockDb.saveBarangays(list);
    return newBarangay;
  },

  getNotifications: (
    accountNumber?: string,
    options?: { userId?: string; email?: string; consumerId?: string; isAdmin?: boolean }
  ): ConsumerNotification[] => {
    const list = getStored<ConsumerNotification[]>(KEYS.NOTIFICATIONS, []);

    // If explicit admin query with no specific consumer target, return all sorted by timestamp
    if (options?.isAdmin && !accountNumber && !options?.userId && !options?.email && !options?.consumerId) {
      return list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }

    const isPlaceholderAccount = (acc?: string): boolean => {
      if (!acc) return true;
      const lower = acc.replace(/^#/, '').trim().toLowerCase();
      return (
        lower === '' ||
        lower === 'pending' ||
        lower === 'pending admin issuance' ||
        lower.startsWith('pending') ||
        lower === 'unassigned' ||
        lower === 'unissued' ||
        lower === 'none' ||
        lower === 'n/a' ||
        lower === 'null' ||
        lower === 'undefined'
      );
    };

    const cleanAccount = (accountNumber || '').replace(/^#/, '').trim().toLowerCase();
    const cleanUserId = (options?.userId || '').trim().toLowerCase();
    const cleanEmail = (options?.email || '').trim().toLowerCase();
    const cleanConsumerId = (options?.consumerId || '').trim().toLowerCase();

    const hasRealAccount = !isPlaceholderAccount(cleanAccount);

    // If consumer has zero valid identifiers, return empty array to prevent ANY data leakage
    if (!hasRealAccount && !cleanUserId && !cleanEmail && !cleanConsumerId) {
      return [];
    }

    const readBroadcastSet = getReadBroadcastNotifSet();
    const viewerIdentityKey = cleanEmail || cleanAccount || cleanUserId || cleanConsumerId;

    const filtered = list
      .filter(n => {
        const nCleanAcc = (n.accountNumber || '').replace(/^#/, '').trim().toLowerCase();
        const inferredType = inferNotificationType(n);
        // District-wide broadcast notifications (ONLY public announcements & tariff advisories — never personal payments/receipts)
        if (nCleanAcc === 'all' || nCleanAcc === 'broadcast' || nCleanAcc === 'district') {
          if (
            isPersonalNotificationType(inferredType) ||
            isTransactionalPaymentOrReceiptItem(n as unknown as Record<string, unknown>)
          ) {
            return false;
          }
          return true;
        }

        const nHasRealAcc = !isPlaceholderAccount(n.accountNumber);
        const nUserId = (n.userId || '').trim().toLowerCase();
        const nEmail = (n.consumerEmail || '').trim().toLowerCase();
        const nConsumerId = (n.consumerId || '').trim().toLowerCase();

        // 1. Direct match on real issued Account Number OR authoritative personal Email
        if (hasRealAccount && nHasRealAcc && cleanAccount === nCleanAcc) {
          return true;
        }
        if (cleanEmail && nEmail && cleanEmail === nEmail) {
          return true;
        }

        // 2. Conflict guards: exclude notifications explicitly bound to a different real account or different email
        if (hasRealAccount && nHasRealAcc && cleanAccount !== nCleanAcc) {
          return false;
        }
        if (cleanEmail && nEmail && cleanEmail !== nEmail) {
          return false;
        }

        // 3. Exact User ID or Consumer ID Match (when email/account do not conflict)
        if (cleanUserId && nUserId && nUserId === cleanUserId) {
          return true;
        }
        if (cleanConsumerId && nConsumerId && nConsumerId === cleanConsumerId) {
          return true;
        }

        // Strictly deny match for any unverified or cross-account notification
        return false;
      })
      .map(n => {
        const nCleanAcc = (n.accountNumber || '').replace(/^#/, '').trim().toLowerCase();
        if (
          (nCleanAcc === 'all' || nCleanAcc === 'broadcast' || nCleanAcc === 'district') &&
          viewerIdentityKey &&
          readBroadcastSet.has(`${viewerIdentityKey}::${n.id}`)
        ) {
          return { ...n, read: true };
        }
        return n;
      });

    return dedupeNotifications(filtered);
  },

  getAllNotifications: (): ConsumerNotification[] => {
    return dedupeNotifications(getStored<ConsumerNotification[]>(KEYS.NOTIFICATIONS, []));
  },

  updateConsumerNotifications: (
    filter: { userId?: string; email?: string; consumerId?: string; oldAccountNumber?: string },
    updates: Partial<ConsumerNotification>
  ): void => {
    const rawList = getStored<ConsumerNotification[]>(KEYS.NOTIFICATIONS, []);
    const list = dedupeNotifications(rawList);
    let modified = list.length !== rawList.length;
    const cleanOldAcc = (filter.oldAccountNumber || '').replace(/^#/, '').trim().toLowerCase();
    const cleanUserId = (filter.userId || '').trim().toLowerCase();
    const cleanEmail = (filter.email || '').trim().toLowerCase();
    const cleanConsumerId = (filter.consumerId || '').trim().toLowerCase();

    const sanitizedUpdates: Partial<ConsumerNotification> = {};
    (Object.keys(updates) as Array<keyof ConsumerNotification>).forEach((k) => {
      const val = updates[k];
      if (val !== undefined) {
        if (k === 'accountNumber' && typeof val === 'string') {
          (sanitizedUpdates as any)[k] = normalizeNotifAccount(val) || val;
        } else if (k === 'consumerEmail' && typeof val === 'string') {
          (sanitizedUpdates as any)[k] = val.trim().toLowerCase();
        } else {
          (sanitizedUpdates as any)[k] = val;
        }
      }
    });

    const syncedDocs: ConsumerNotification[] = [];
    const updated = list.map(n => {
      const nCleanAcc = (n.accountNumber || '').replace(/^#/, '').trim().toLowerCase();
      if (nCleanAcc === 'all' || nCleanAcc === 'broadcast' || nCleanAcc === 'district') {
        return n;
      }
      const nUserId = (n.userId || '').trim().toLowerCase();
      const nEmail = (n.consumerEmail || '').trim().toLowerCase();
      const nConsumerId = (n.consumerId || '').trim().toLowerCase();

      const isMatch = (cleanUserId && nUserId && nUserId === cleanUserId) ||
                      (cleanEmail && nEmail && nEmail === cleanEmail) ||
                      (cleanConsumerId && nConsumerId && nConsumerId === cleanConsumerId) ||
                      (cleanOldAcc && nCleanAcc && nCleanAcc === cleanOldAcc);

      if (isMatch) {
        const next: ConsumerNotification = { ...n };
        let itemChanged = false;

        if (sanitizedUpdates.accountNumber) {
          const curAcc = normalizeNotifAccount(n.accountNumber);
          const nextAcc = normalizeNotifAccount(sanitizedUpdates.accountNumber);
          // Upgrade pending/missing account numbers or explicitly targeted oldAccountNumber
          if (!isIssuedNotifAccount(curAcc) || (cleanOldAcc && nCleanAcc === cleanOldAcc)) {
            if (curAcc !== nextAcc) {
              next.accountNumber = nextAcc;
              itemChanged = true;
            }
          }
        }
        if (sanitizedUpdates.consumerEmail && !n.consumerEmail) {
          next.consumerEmail = sanitizedUpdates.consumerEmail;
          itemChanged = true;
        }
        if (sanitizedUpdates.userId && !n.userId) {
          next.userId = sanitizedUpdates.userId;
          itemChanged = true;
        }
        if (sanitizedUpdates.consumerId && !n.consumerId) {
          next.consumerId = sanitizedUpdates.consumerId;
          itemChanged = true;
        }
        if (sanitizedUpdates.read !== undefined && Boolean(n.read) !== Boolean(sanitizedUpdates.read)) {
          next.read = Boolean(sanitizedUpdates.read);
          itemChanged = true;
        }

        if (itemChanged) {
          modified = true;
          syncedDocs.push(next);
          return next;
        }
      }
      return n;
    });

    if (modified) {
      const finalDeduped = dedupeNotifications(updated);
      setStored(KEYS.NOTIFICATIONS, finalDeduped);
      syncedDocs.slice(0, 15).forEach((docItem) => {
        syncDocToFirestore(COLLECTIONS.NOTIFICATIONS, docItem.id, docItem as unknown as Record<string, unknown>);
      });
    }
  },

  addNotification: (
    notif: Omit<ConsumerNotification, 'id' | 'timestamp' | 'read'> & { id?: string; timestamp?: string }
  ): ConsumerNotification => {
    const rawList = getStored<ConsumerNotification[]>(KEYS.NOTIFICATIONS, []);
    const list = dedupeNotifications(rawList);
    const cleanAcc = normalizeNotifAccount(notif.accountNumber) || notif.accountNumber || 'PENDING';
    const cleanEmail = notif.consumerEmail ? notif.consumerEmail.trim().toLowerCase() : undefined;

    const candidate: ConsumerNotification = {
      ...notif,
      type: inferNotificationType(notif),
      accountNumber: cleanAcc,
      ...(cleanEmail ? { consumerEmail: cleanEmail } : {}),
      id: notif.id || `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: notif.timestamp || new Date().toISOString(),
      read: false,
    };

    const candidateSemKey = getNotificationSemanticKey(candidate);
    const existing = list.find((item) => getNotificationSemanticKey(item) === candidateSemKey);
    if (existing) {
      if (list.length !== rawList.length) {
        setStored(KEYS.NOTIFICATIONS, list);
      }
      return existing;
    }

    const nextList = dedupeNotifications([candidate, ...list]);
    setStored(KEYS.NOTIFICATIONS, nextList);
    syncDocToFirestore(COLLECTIONS.NOTIFICATIONS, candidate.id, candidate as unknown as Record<string, unknown>);
    safeBackendFetch('/api/notifications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(candidate)
    }).catch(() => {});
    return candidate;
  },

  mergeExternalNotifications: (incoming: ConsumerNotification[]): boolean => {
    if (!Array.isArray(incoming) || incoming.length === 0) return false;
    const prevRaw = localStorage.getItem(KEYS.NOTIFICATIONS) || '[]';
    const currentList = getStored<ConsumerNotification[]>(KEYS.NOTIFICATIONS, []);
    const merged = dedupeNotifications([...currentList, ...incoming]);
    const nextRaw = JSON.stringify(merged);
    if (prevRaw === nextRaw) {
      return false;
    }
    setStored(KEYS.NOTIFICATIONS, merged);
    return true;
  },

  markNotificationRead: (id: string): void => {
    const list = dedupeNotifications(getStored<ConsumerNotification[]>(KEYS.NOTIFICATIONS, []));
    const target = list.find(n => n.id === id);
    const targetAcc = (target?.accountNumber || '').replace(/^#/, '').trim().toLowerCase();
    if (target && (targetAcc === 'all' || targetAcc === 'broadcast' || targetAcc === 'district')) {
      const cur = mockDb.getCurrentUser();
      const viewerKey = (cur?.email || cur?.linkedAccountNumber || cur?.id || 'viewer').trim().toLowerCase();
      markBroadcastNotifReadForIdentity(id, viewerKey);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('twd_database_updated', { detail: { key: KEYS.NOTIFICATIONS, timestamp: Date.now() } }));
      }
      return;
    }
    if (target && target.read) return;
    const updated = list.map(n => n.id === id ? { ...n, read: true } : n);
    setStored(KEYS.NOTIFICATIONS, updated);
    syncDocToFirestore(COLLECTIONS.NOTIFICATIONS, id, { read: true });
    safeBackendFetch(`/api/notifications/${encodeURIComponent(id)}/read`, { method: 'PATCH' }).catch(() => {});
  },

  markAllNotificationsRead: (ids?: string[]): void => {
    const list = dedupeNotifications(getStored<ConsumerNotification[]>(KEYS.NOTIFICATIONS, []));
    const idSet = ids && ids.length > 0 ? new Set(ids) : null;
    const cur = mockDb.getCurrentUser();
    const viewerKey = (cur?.email || cur?.linkedAccountNumber || cur?.id || 'viewer').trim().toLowerCase();

    let broadcastUpdated = false;
    const changedItems: ConsumerNotification[] = [];
    const updated = list.map((n) => {
      if (idSet && !idSet.has(n.id)) return n;
      const nAcc = (n.accountNumber || '').replace(/^#/, '').trim().toLowerCase();
      if (nAcc === 'all' || nAcc === 'broadcast' || nAcc === 'district') {
        markBroadcastNotifReadForIdentity(n.id, viewerKey);
        broadcastUpdated = true;
        return n;
      }
      if (!n.read) {
        const next = { ...n, read: true };
        changedItems.push(next);
        return next;
      }
      return n;
    });

    if (changedItems.length > 0) {
      setStored(KEYS.NOTIFICATIONS, updated);
      changedItems.slice(0, 20).forEach((item) => {
        syncDocToFirestore(COLLECTIONS.NOTIFICATIONS, item.id, { read: true });
      });
      safeBackendFetch('/api/notifications/mark-all-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: changedItems.map((i) => i.id),
          accountNumber: cur?.linkedAccountNumber,
          email: cur?.email,
          userId: cur?.id,
        }),
      }).catch(() => {});
    } else if (broadcastUpdated && typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('twd_database_updated', { detail: { key: KEYS.NOTIFICATIONS, timestamp: Date.now() } })
      );
    }
  },

  // Consumer Service Reports & Admin Reply Methods
  dedupeReplies: (replies?: ConsumerReportReply[]): ConsumerReportReply[] => {
    if (!Array.isArray(replies) || replies.length === 0) return [];
    const sorted = [...replies]
      .filter(Boolean)
      .sort((a, b) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());
    const result: ConsumerReportReply[] = [];
    const seenIds = new Set<string>();
    let hasAutoAck = false;

    for (const rep of sorted) {
      const rid = (rep.id || '').trim();
      if (rid && seenIds.has(rid)) continue;

      const isAutoAck =
        rid.startsWith('ACK-') ||
        rep.senderId === 'system-admin-ack' ||
        (rep.senderRole === 'admin' &&
          (rep.message || '').toLowerCase().includes('successfully delivered to the tagoloan water district'));
      if (isAutoAck) {
        if (hasAutoAck) continue;
        hasAutoAck = true;
        if (rid) seenIds.add(rid);
        result.push(rep);
        continue;
      }

      const normMsg = (rep.message || '').trim().replace(/\s+/g, ' ').toLowerCase();
      const repTime = new Date(rep.timestamp || 0).getTime();

      const dupIdx = result.findIndex((existing) => {
        if (existing.senderRole !== rep.senderRole) return false;
        const exMsg = (existing.message || '').trim().replace(/\s+/g, ' ').toLowerCase();
        if (exMsg !== normMsg) return false;
        const exTime = new Date(existing.timestamp || 0).getTime();
        // Treat identical message from same role within 5 minutes as optimistic/server sync duplicate
        return Math.abs(repTime - exTime) <= 5 * 60 * 1000;
      });

      if (dupIdx >= 0) {
        // Keep statusUpdate metadata if the incoming copy carries it
        if (!result[dupIdx].statusUpdate && rep.statusUpdate) {
          result[dupIdx] = { ...result[dupIdx], statusUpdate: rep.statusUpdate };
        }
        if (rid) seenIds.add(rid);
        continue;
      }

      if (rid) seenIds.add(rid);
      result.push(rep);
    }

    return result;
  },

  getReports: (accountNumber?: string): ConsumerReport[] => {
    const rawList = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const list = rawList.map((r) => ({
      ...r,
      replies: mockDb.dedupeReplies(r.replies),
    }));
    if (accountNumber) {
      const cleanTarget = accountNumber.trim().toLowerCase();
      return list
        .filter(
          r =>
            (r.accountNumber || '').trim().toLowerCase() === cleanTarget ||
            (r.consumerEmail && r.consumerEmail.trim().toLowerCase() === cleanTarget)
        )
        .sort(compareReportsCanonical);
    }
    return list.sort(compareReportsCanonical);
  },

  getReportById: (id: string): ConsumerReport | undefined => {
    const list = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const found = list.find(r => r.id === id || r.ticketNumber === id);
    return found ? { ...found, replies: mockDb.dedupeReplies(found.replies) } : undefined;
  },

  saveReports: (reports: ConsumerReport[]): void => {
    const cleaned = reports
      .map((r) => ({
        ...r,
        replies: mockDb.dedupeReplies(r.replies),
      }))
      .sort(compareReportsCanonical);
    const changed = diffChangedItems(KEYS.REPORTS, cleaned, 'id');
    setStored(KEYS.REPORTS, cleaned);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.REPORTS, changed, 'id');
  },

  mergeExternalReports: (incoming: ConsumerReport[]): ConsumerReport[] => {
    const localList = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const readTokens = getAdminReadAlertTokens();
    if (!Array.isArray(incoming) || incoming.length === 0) {
      return localList
        .map((r) => {
          const cleanReplies = mockDb.dedupeReplies(r.replies);
          const candidate = { ...r, replies: cleanReplies };
          return readTokens.has(getAdminReportAlertToken(candidate))
            ? { ...candidate, hasUnreadConsumerUpdate: false }
            : candidate;
        })
        .sort(compareReportsCanonical);
    }
    const map = new Map<string, ConsumerReport>();
    localList.forEach(lr => {
      if (lr && lr.id) map.set(lr.id, { ...lr, replies: mockDb.dedupeReplies(lr.replies) });
    });
    incoming.forEach(ir => {
      if (!ir || (!ir.id && !ir.ticketNumber)) return;
      let existingKey = ir.id && map.has(ir.id) ? ir.id : undefined;
      if (!existingKey && ir.ticketNumber) {
        const foundEntry = Array.from(map.entries()).find(([, v]) => v.ticketNumber === ir.ticketNumber);
        if (foundEntry) existingKey = foundEntry[0];
      }
      if (!existingKey) {
        const key = ir.id || ir.ticketNumber;
        const candidate: ConsumerReport = { ...ir, id: key, replies: mockDb.dedupeReplies(ir.replies) };
        if (readTokens.has(getAdminReportAlertToken(candidate))) {
          candidate.hasUnreadConsumerUpdate = false;
        }
        map.set(key, candidate);
      } else {
        const prev = map.get(existingKey)!;
        const prevReplies = Array.isArray(prev.replies) ? prev.replies : [];
        const irReplies = Array.isArray(ir.replies) ? ir.replies : [];
        const mergedReplies = mockDb.dedupeReplies([...prevReplies, ...irReplies]);
        const prevTime = new Date(prev.updatedAt || 0).getTime();
        const irTime = new Date(ir.updatedAt || 0).getTime();
        const irNewer = irTime > prevTime || (irTime === prevTime && irReplies.length > prevReplies.length);
        const primary = irNewer ? ir : prev;
        const secondary = irNewer ? prev : ir;

        const prevConsumerCount = prevReplies.filter(m => m && m.senderRole === 'consumer').length;
        const mergedConsumerCount = mergedReplies.filter(m => m && m.senderRole === 'consumer').length;

        const mergedItem: ConsumerReport = {
          ...secondary,
          ...primary,
          id: existingKey,
          sourceNotificationId: primary.sourceNotificationId || secondary.sourceNotificationId,
          referencedNotice: primary.referencedNotice || secondary.referencedNotice,
          replies: mergedReplies,
        };

        if (
          readTokens.has(getAdminReportAlertToken(mergedItem)) ||
          (prev.hasUnreadConsumerUpdate === false && mergedConsumerCount <= prevConsumerCount)
        ) {
          mergedItem.hasUnreadConsumerUpdate = false;
        }

        map.set(existingKey, mergedItem);
      }
    });
    const merged = Array.from(map.values()).sort(compareReportsCanonical);
    const changed = diffChangedItems(KEYS.REPORTS, merged, 'id');
    setStored(KEYS.REPORTS, merged);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.REPORTS, changed, 'id');
    return merged;
  },

  createReport: (reportData: Omit<ConsumerReport, 'id' | 'ticketNumber' | 'createdAt' | 'updatedAt' | 'replies' | 'status' | 'hasUnreadAdminReply' | 'hasUnreadConsumerUpdate'> & { status?: ConsumerReport['status']; initialReply?: string; hasUnreadAdminReply?: boolean; hasUnreadConsumerUpdate?: boolean }): ConsumerReport => {
    const list = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const id = `REP-${Date.now()}`;
    const randNum = Math.floor(1000 + Math.random() * 9000);
    const ticketNumber = `TWD-CR-${new Date().getFullYear()}-${randNum}`;
    const nowMs = Date.now();
    const now = new Date(nowMs).toISOString();
    const ackTime = new Date(nowMs + 1).toISOString();

    const replies: ConsumerReportReply[] = [];
    if (reportData.description || reportData.initialReply) {
      replies.push({
        id: `INIT-${ticketNumber}`,
        reportId: id,
        senderId: reportData.accountNumber || 'consumer',
        senderName: reportData.consumerName,
        senderRole: 'consumer',
        message: reportData.description || reportData.initialReply || '',
        timestamp: now
      });
    }

    const refNotice = reportData.referencedNotice;
    const ackMessage = refNotice
      ? `Good day, ${reportData.consumerName || 'Valued Consumer'}! Your reply (#${ticketNumber}) regarding Official Notice "${refNotice.subject}"${refNotice.meterNumber ? ` (Meter #${refNotice.meterNumber}${refNotice.meterStatus ? ` · Status: ${refNotice.meterStatus.toUpperCase()}` : ''})` : ''} has been linked and delivered directly to Tagoloan Water District Administration with all notice details attached. Our Administration team will respond directly to this notice thread.`
      : `Good day, ${reportData.consumerName || 'Valued Consumer'}! Your inquiry/report (#${ticketNumber}) has been successfully delivered to the Tagoloan Water District Administration. Our Customer Service team has been notified and will review your concern—please wait shortly for an official reply. Thank you for reaching out and for your patience!`;

    // Immediate automated Admin acknowledgement message confirming delivery
    replies.push({
      id: `ACK-${ticketNumber}`,
      reportId: id,
      senderId: 'system-admin-ack',
      senderName: 'TWD Customer Service Desk',
      senderRole: 'admin',
      message: ackMessage,
      timestamp: ackTime
    });

    const newReport: ConsumerReport = {
      ...reportData,
      id,
      ticketNumber,
      status: 'pending',
      createdAt: now,
      updatedAt: ackTime,
      replies,
      hasUnreadAdminReply: false,
      hasUnreadConsumerUpdate: true
    };

    list.unshift(newReport);
    mockDb.saveReports(list);

    mockDb.addAuditLog(
      reportData.accountNumber || 'consumer',
      reportData.consumerName,
      'consumer',
      refNotice ? 'Replied to Official Admin Notice' : 'Filed Service Report',
      refNotice
        ? `Replied via Ticket #${ticketNumber} regarding Official Notice "${refNotice.subject}"${refNotice.meterNumber ? ` (Meter #${refNotice.meterNumber})` : ''}.`
        : `Filed concern #${ticketNumber} (${reportData.category.toUpperCase()}): "${reportData.title}".`
    );

    return newReport;
  },

  replyToReport: (
    reportId: string, 
    reply: Omit<ConsumerReportReply, 'id' | 'timestamp' | 'reportId'> & { id?: string; timestamp?: string }, 
    newStatus?: ConsumerReport['status'],
    assignedStaff?: string
  ): ConsumerReport | null => {
    const list = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const idx = list.findIndex(r => r.id === reportId || r.ticketNumber === reportId);
    if (idx === -1) return null;

    const report = list[idx];
    const now = reply.timestamp || new Date().toISOString();
    const deterministicId = reply.id || `REP-MSG-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const replyItem: ConsumerReportReply = {
      ...reply,
      id: deterministicId,
      reportId: report.id,
      timestamp: now,
      statusUpdate: newStatus
    };

    const prevDeduped = mockDb.dedupeReplies(report.replies);
    const mergedReplies = mockDb.dedupeReplies([...prevDeduped, replyItem]);
    const isDuplicateSubmission = mergedReplies.length === prevDeduped.length;

    const nextStatus = newStatus || report.status;
    const isResolved = nextStatus === 'resolved';

    const updated: ConsumerReport = {
      ...report,
      status: nextStatus,
      updatedAt: now,
      resolvedAt: isResolved ? (report.resolvedAt || now) : report.resolvedAt,
      assignedStaff: assignedStaff !== undefined ? assignedStaff : report.assignedStaff,
      replies: mergedReplies,
      hasUnreadAdminReply: reply.senderRole === 'admin',
      hasUnreadConsumerUpdate: reply.senderRole === 'consumer'
    };

    list[idx] = updated;
    mockDb.saveReports(list);

    if (!isDuplicateSubmission) {
      if (reply.senderRole === 'admin') {
        const consumers = mockDb.getConsumers();
        const matchedConsumer = consumers.find(c => 
          (report.accountNumber && c.accountNumber === report.accountNumber) ||
          (report.consumerEmail && c.email && c.email.toLowerCase() === report.consumerEmail.toLowerCase())
        );

        const refNotice = updated.referencedNotice;
        const contextualSubject = refNotice
          ? refNotice.meterStatus
            ? `Admin Reply Re: Water Meter Status (${refNotice.meterStatus === 'maintenance' ? 'Under Maintenance' : refNotice.meterStatus.charAt(0).toUpperCase() + refNotice.meterStatus.slice(1)})${refNotice.meterNumber ? ` — Meter #${refNotice.meterNumber}` : ''}`
            : `Admin Reply Re: ${refNotice.subject}`
          : `Official Admin Reply — ${updated.title || `Concern #${report.ticketNumber}`}`;

        const safeTitle = contextualSubject.slice(0, 220);
        const fullReplyBody = String(reply.message || '').trim().slice(0, 2400);

        mockDb.addNotification({
          id: `notif-rep-${deterministicId.replace(/[^a-zA-Z0-9_-]/g, '_')}`,
          accountNumber: report.accountNumber,
          consumerId: matchedConsumer?.id,
          userId: matchedConsumer?.linkedUserId,
          consumerEmail: report.consumerEmail || matchedConsumer?.email,
          subject: safeTitle,
          title: safeTitle,
          message: fullReplyBody,
          type: 'report',
          reportId: report.id,
          ticketNumber: report.ticketNumber,
          replyId: deterministicId,
          sentByAdmin: reply.senderName,
          updatedByAdmin: reply.senderName,
          isFromAdmin: true,
          referencedNotice: refNotice,
        });

        mockDb.addAuditLog(
          reply.senderId,
          reply.senderName,
          'admin',
          'Replied to Consumer Report',
          `Responded to Ticket #${report.ticketNumber} for ${report.consumerName}${refNotice ? ` (Re: ${refNotice.subject})` : ''} (Status: ${nextStatus}).`
        );
      } else {
        mockDb.addAuditLog(
          reply.senderId,
          reply.senderName,
          'consumer',
          'Updated Service Report',
          `Added follow-up message to Ticket #${report.ticketNumber}${updated.referencedNotice ? ` (Re: ${updated.referencedNotice.subject})` : ''}.`
        );
      }
    }

    return updated;
  },

  updateReportStatus: (reportId: string, status: ConsumerReport['status'], assignedStaff?: string): ConsumerReport | null => {
    const list = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const idx = list.findIndex(r => r.id === reportId || r.ticketNumber === reportId);
    if (idx === -1) return null;

    const report = list[idx];
    const now = new Date().toISOString();
    const isResolved = status === 'resolved';

    const updated: ConsumerReport = {
      ...report,
      status,
      updatedAt: now,
      resolvedAt: isResolved ? now : report.resolvedAt,
      assignedStaff: assignedStaff !== undefined ? assignedStaff : report.assignedStaff,
      hasUnreadAdminReply: true
    };

    list[idx] = updated;
    mockDb.saveReports(list);

    const consumers = mockDb.getConsumers();
    const matchedConsumer = consumers.find(c => 
      (report.accountNumber && c.accountNumber === report.accountNumber) ||
      (report.consumerEmail && c.email && c.email.toLowerCase() === report.consumerEmail.toLowerCase())
    );
    const refNotice = updated.referencedNotice;
    const statusTitle = refNotice
      ? `Status Updated (${status.toUpperCase().replace('_', ' ')}) — Re: ${refNotice.subject}`.slice(0, 220)
      : `Status Updated for Ticket #${report.ticketNumber}`;

    mockDb.addNotification({
      accountNumber: report.accountNumber,
      consumerId: matchedConsumer?.id,
      userId: matchedConsumer?.linkedUserId,
      consumerEmail: report.consumerEmail || matchedConsumer?.email,
      subject: statusTitle,
      title: statusTitle,
      message: `Tagoloan Water District Administration updated your inquiry (#${report.ticketNumber}) status to ${status.toUpperCase().replace('_', ' ')}.${assignedStaff ? ` Assigned to: ${assignedStaff}.` : ''}`,
      type: 'report',
      reportId: report.id,
      ticketNumber: report.ticketNumber,
      sentByAdmin: assignedStaff || 'TWD Administration',
      isFromAdmin: true,
      referencedNotice: refNotice,
    });

    return updated;
  },

  isReportUnreadForAdmin: (rep?: ConsumerReport | null): boolean => {
    if (!rep) return false;
    const readTokens = getAdminReadAlertTokens();
    if (readTokens.has(getAdminReportAlertToken(rep))) return false;
    if (rep.hasUnreadConsumerUpdate === false) return false;
    return Boolean(
      rep.hasUnreadConsumerUpdate === true ||
        (rep.hasUnreadConsumerUpdate === undefined && rep.status === 'pending')
    );
  },

  isInstallationUnreadForAdmin: (req?: WaterMeterInstallationRequest | null): boolean => {
    if (!req) return false;
    if (req.status === 'Cancelled' || req.accountValidationStatus === 'validated') return false;
    const readTokens = getAdminReadAlertTokens();
    if (readTokens.has(getAdminInstallationAlertToken(req))) return false;
    if (req.hasUnreadAdminAlert === false) return false;
    return Boolean(
      req.hasUnreadAdminAlert === true ||
        (req.hasUnreadAdminAlert === undefined && req.status === 'Pending Review')
    );
  },

  markReportReadByConsumer: (reportId: string): void => {
    const list = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const updated = list.map(r => (r.id === reportId || r.ticketNumber === reportId) ? { ...r, hasUnreadAdminReply: false } : r);
    setStored(KEYS.REPORTS, updated);
    const target = updated.find(r => r.id === reportId || r.ticketNumber === reportId);
    if (target) {
      syncDocToFirestore(COLLECTIONS.REPORTS, target.id, target as unknown as Record<string, unknown>);
      safeBackendFetch(`/api/reports/${encodeURIComponent(target.id)}/read`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'consumer' }),
      }).catch(() => {});
    }
  },

  markReportReadByAdmin: (reportId: string, fallbackRep?: ConsumerReport): ConsumerReport[] => {
    const list = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const existsInList = list.some(r => r.id === reportId || r.ticketNumber === reportId);
    const baseList =
      !existsInList && fallbackRep
        ? [{ ...fallbackRep, hasUnreadConsumerUpdate: false }, ...list]
        : list;

    const tokensToAdd: string[] = [];
    if (fallbackRep) {
      tokensToAdd.push(getAdminReportAlertToken(fallbackRep));
    }

    const updated = baseList
      .map(r => {
        if (r.id === reportId || r.ticketNumber === reportId) {
          tokensToAdd.push(getAdminReportAlertToken(r));
          return { ...r, hasUnreadConsumerUpdate: false };
        }
        return r;
      })
      .sort(compareReportsCanonical);

    addAdminReadAlertTokens(tokensToAdd);
    setStored(KEYS.REPORTS, updated);

    const target = updated.find(r => r.id === reportId || r.ticketNumber === reportId);
    if (target) {
      syncDocToFirestore(COLLECTIONS.REPORTS, target.id, target as unknown as Record<string, unknown>);
      safeBackendFetch(`/api/reports/${encodeURIComponent(target.id)}/read`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'admin' }),
      }).catch(() => {});
    }
    return updated;
  },

  // =========================================================================
  // NEW CONSUMER WATER METER INSTALLATION SCHEDULING & ACCOUNT VALIDATION
  // =========================================================================

  getInstallationRequests: (): WaterMeterInstallationRequest[] => {
    const list = getStored<WaterMeterInstallationRequest[]>(KEYS.INSTALLATIONS, []);
    const readTokens = getAdminReadAlertTokens();
    return [...list]
      .map((r) =>
        readTokens.has(getAdminInstallationAlertToken(r))
          ? { ...r, hasUnreadAdminAlert: false }
          : r
      )
      .sort(compareInstallationsCanonical);
  },

  saveInstallationRequests: (requests: WaterMeterInstallationRequest[]): void => {
    const sorted = [...requests].sort(compareInstallationsCanonical);
    const changed = diffChangedItems(KEYS.INSTALLATIONS, sorted, 'id');
    setStored(KEYS.INSTALLATIONS, sorted);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.INSTALLATIONS, changed, 'id');
  },

  mergeExternalInstallations: (incoming: WaterMeterInstallationRequest[]): WaterMeterInstallationRequest[] => {
    const localList = getStored<WaterMeterInstallationRequest[]>(KEYS.INSTALLATIONS, []);
    const readTokens = getAdminReadAlertTokens();
    if (!Array.isArray(incoming) || incoming.length === 0) {
      return [...localList]
        .map((r) =>
          readTokens.has(getAdminInstallationAlertToken(r))
            ? { ...r, hasUnreadAdminAlert: false }
            : r
        )
        .sort(compareInstallationsCanonical);
    }
    const map = new Map<string, WaterMeterInstallationRequest>();
    localList.forEach((lr) => {
      if (lr && lr.id) map.set(lr.id, lr);
    });
    incoming.forEach((ir) => {
      if (!ir || (!ir.id && !ir.applicationNumber)) return;
      let existingKey = ir.id && map.has(ir.id) ? ir.id : undefined;
      if (!existingKey && ir.applicationNumber) {
        const found = Array.from(map.entries()).find(([, v]) => v.applicationNumber === ir.applicationNumber);
        if (found) existingKey = found[0];
      }
      if (!existingKey) {
        const k = ir.id || ir.applicationNumber;
        const candidate: WaterMeterInstallationRequest = {
          ...ir,
          id: k,
          history: Array.isArray(ir.history) ? ir.history : [],
        };
        if (readTokens.has(getAdminInstallationAlertToken(candidate))) {
          candidate.hasUnreadAdminAlert = false;
        }
        map.set(k, candidate);
      } else {
        const prev = map.get(existingKey)!;
        const prevTime = new Date(prev.updatedAt || 0).getTime();
        const irTime = new Date(ir.updatedAt || 0).getTime();
        const irNewer = irTime > prevTime;
        const primary = irNewer ? ir : prev;
        const secondary = irNewer ? prev : ir;
        const histMap = new Map<string, InstallationHistoryEntry>();
        [...(prev.history || []), ...(ir.history || [])].forEach((h) => {
          if (h && h.id) histMap.set(h.id, h);
        });
        const mergedHist = Array.from(histMap.values()).sort(
          (a, b) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime()
        );
        const prevConsumerEvents = Array.isArray(prev.history)
          ? prev.history.filter(h => h && h.actorRole === 'consumer').length
          : 0;
        const mergedConsumerEvents = mergedHist.filter(h => h && h.actorRole === 'consumer').length;

        const mergedItem: WaterMeterInstallationRequest = {
          ...secondary,
          ...primary,
          id: existingKey,
          meterSerialNumber: primary.meterSerialNumber || secondary.meterSerialNumber,
          assignedAccountNumber: primary.assignedAccountNumber || secondary.assignedAccountNumber,
          assignedMeterTagNumber: primary.assignedMeterTagNumber || secondary.assignedMeterTagNumber,
          history: mergedHist,
        };

        if (
          readTokens.has(getAdminInstallationAlertToken(mergedItem)) ||
          (prev.hasUnreadAdminAlert === false && mergedConsumerEvents <= prevConsumerEvents)
        ) {
          mergedItem.hasUnreadAdminAlert = false;
        }

        map.set(existingKey, mergedItem);
      }
    });
    const merged = Array.from(map.values()).sort(compareInstallationsCanonical);
    const changed = diffChangedItems(KEYS.INSTALLATIONS, merged, 'id');
    setStored(KEYS.INSTALLATIONS, merged);
    if (changed.length > 0) syncBatchToFirestore(COLLECTIONS.INSTALLATIONS, changed, 'id');
    return merged;
  },

  markInstallationReadByAdmin: (
    requestId: string,
    fallbackReq?: WaterMeterInstallationRequest
  ): WaterMeterInstallationRequest[] => {
    const list = getStored<WaterMeterInstallationRequest[]>(KEYS.INSTALLATIONS, []);
    const existsInList = list.some(
      (r) => r.id === requestId || r.applicationNumber === requestId
    );
    const baseList =
      !existsInList && fallbackReq
        ? [{ ...fallbackReq, hasUnreadAdminAlert: false }, ...list]
        : list;

    const tokensToAdd: string[] = [];
    if (fallbackReq) {
      tokensToAdd.push(getAdminInstallationAlertToken(fallbackReq));
    }

    const updated = baseList
      .map((r) => {
        if (r.id === requestId || r.applicationNumber === requestId) {
          tokensToAdd.push(getAdminInstallationAlertToken(r));
          return { ...r, hasUnreadAdminAlert: false };
        }
        return r;
      })
      .sort(compareInstallationsCanonical);

    addAdminReadAlertTokens(tokensToAdd);
    setStored(KEYS.INSTALLATIONS, updated);
    const target = updated.find((r) => r.id === requestId || r.applicationNumber === requestId);
    if (target) {
      syncDocToFirestore(COLLECTIONS.INSTALLATIONS, target.id, target as unknown as Record<string, unknown>);
      safeBackendFetch(`/api/installations/${encodeURIComponent(target.id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ request: target, hasUnreadAdminAlert: false, markReadOnly: true }),
      }).catch(() => {});
    }
    return updated;
  },

  markAllAdminNotificationsRead: (
    extraInstallations?: WaterMeterInstallationRequest[],
    extraReports?: ConsumerReport[]
  ): { installations: WaterMeterInstallationRequest[]; reports: ConsumerReport[] } => {
    const tokensToAdd: string[] = [];

    // 1. Mark all Installation Requests read
    const storedInst = getStored<WaterMeterInstallationRequest[]>(KEYS.INSTALLATIONS, []);
    const instMap = new Map<string, WaterMeterInstallationRequest>();
    [...storedInst, ...(Array.isArray(extraInstallations) ? extraInstallations : [])].forEach((r) => {
      if (r && r.id) instMap.set(r.id, r);
    });
    const changedInst: WaterMeterInstallationRequest[] = [];
    const updatedInst = Array.from(instMap.values())
      .map((r) => {
        tokensToAdd.push(getAdminInstallationAlertToken(r));
        if (r.hasUnreadAdminAlert !== false) {
          const next = { ...r, hasUnreadAdminAlert: false };
          changedInst.push(next);
          return next;
        }
        return r;
      })
      .sort(compareInstallationsCanonical);

    // 2. Mark all Consumer Reports read
    const storedRep = getStored<ConsumerReport[]>(KEYS.REPORTS, INITIAL_REPORTS);
    const repMap = new Map<string, ConsumerReport>();
    [...storedRep, ...(Array.isArray(extraReports) ? extraReports : [])].forEach((r) => {
      if (r && r.id) repMap.set(r.id, r);
    });
    const changedRep: ConsumerReport[] = [];
    const updatedRep = Array.from(repMap.values())
      .map((r) => {
        tokensToAdd.push(getAdminReportAlertToken(r));
        if (r.hasUnreadConsumerUpdate !== false) {
          const next = { ...r, hasUnreadConsumerUpdate: false };
          changedRep.push(next);
          return next;
        }
        return r;
      })
      .sort(compareReportsCanonical);

    addAdminReadAlertTokens(tokensToAdd);
    setStored(KEYS.INSTALLATIONS, updatedInst);
    setStored(KEYS.REPORTS, updatedRep);

    if (changedInst.length > 0) {
      syncBatchToFirestore(COLLECTIONS.INSTALLATIONS, changedInst, 'id');
    }
    if (changedRep.length > 0) {
      syncBatchToFirestore(COLLECTIONS.REPORTS, changedRep, 'id');
    }

    safeBackendFetch('/api/installations/mark-all-read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: updatedInst.map((i) => i.id) }),
    }).catch(() => {});

    safeBackendFetch('/api/reports/mark-all-read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: updatedRep.map((r) => r.id) }),
    }).catch(() => {});

    return { installations: updatedInst, reports: updatedRep };
  },

  createInstallationRequest: (payload: {
    applicationNumber?: string;
    consumerId?: string;
    linkedUserId?: string;
    userId?: string;
    consumerName: string;
    consumerEmail: string;
    contactNumber: string;
    address: string;
    barangay: string;
    barangayId?: string;
    sitioZone?: string;
    consumerType?: 'Residential' | 'Commercial';
    preferredInstallationDate: string;
    consumerRemarks?: string;
  }): WaterMeterInstallationRequest => {
    const list = getStored<WaterMeterInstallationRequest[]>(KEYS.INSTALLATIONS, []);
    const existingAppNums = [
      ...list.map((r) => r.applicationNumber),
      ...mockDb.getConsumers().map((c) => c.applicationNumber),
    ];
    const applicationNumber = payload.applicationNumber || generateApplicationNumber(existingAppNums);
    const now = new Date().toISOString();
    const id = `INST-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
    const resolvedLinkedUserId = payload.linkedUserId || payload.userId;

    const historyEntry: InstallationHistoryEntry = {
      id: `HIST-${Date.now()}-1`,
      status: 'Pending Review',
      timestamp: now,
      actorName: payload.consumerName.trim(),
      actorRole: 'consumer',
      action: 'Submitted Water Meter Installation Request',
      scheduledDate: payload.preferredInstallationDate,
      remarks: payload.consumerRemarks?.trim() || 'Water meter installation request submitted by consumer.',
    };

    const newReq: WaterMeterInstallationRequest = {
      id,
      applicationNumber,
      consumerId: payload.consumerId || resolvedLinkedUserId,
      linkedUserId: resolvedLinkedUserId,
      consumerName: payload.consumerName.trim(),
      consumerEmail: payload.consumerEmail.trim().toLowerCase(),
      contactNumber: payload.contactNumber.trim(),
      address: payload.address.trim(),
      barangay: payload.barangay.trim(),
      barangayId: payload.barangayId,
      sitioZone: payload.sitioZone,
      consumerType: payload.consumerType || 'Residential',
      preferredInstallationDate: payload.preferredInstallationDate,
      submissionDate: now,
      status: 'Pending Review',
      consumerRemarks: payload.consumerRemarks?.trim() || '',
      adminRemarks: '',
      accountValidationStatus: 'pending_installation',
      hasUnreadAdminAlert: true,
      updatedAt: now,
      history: [historyEntry],
    };

    const nextList = [newReq, ...list];
    mockDb.saveInstallationRequests(nextList);

    // Update linked Consumer & User status to 'pending_installation'
    const cleanEmail = newReq.consumerEmail;
    const consumers = mockDb.getConsumers();
    let updatedConsumer: Consumer | undefined;
    const nextConsumers = consumers.map((c) => {
      const matches =
        (cleanEmail && c.email && c.email.trim().toLowerCase() === cleanEmail) ||
        (newReq.linkedUserId && c.linkedUserId === newReq.linkedUserId) ||
        (c.applicationNumber && c.applicationNumber === applicationNumber);
      if (!matches || isRealIssuedAccountNumber(c.accountNumber)) return c;
      updatedConsumer = {
        ...c,
        applicationNumber,
        hasExistingMeter: false,
        installationRequestId: newReq.id,
        installationStatus: 'Pending Review',
        accountValidationStatus: 'pending_installation',
        status: 'pending_installation',
      };
      return updatedConsumer;
    });
    if (updatedConsumer) {
      mockDb.saveConsumers(nextConsumers);
    }

    const users = mockDb.getUsers();
    let usersModified = false;
    const nextUsers = users.map((u) => {
      if (u.role === 'admin' || isRealIssuedAccountNumber(u.linkedAccountNumber)) return u;
      const matches =
        (cleanEmail && u.email && u.email.trim().toLowerCase() === cleanEmail) ||
        (newReq.linkedUserId && u.id === newReq.linkedUserId);
      if (!matches) return u;
      usersModified = true;
      return { ...u, status: 'pending_installation' as const };
    });
    if (usersModified) {
      mockDb.saveUsers(nextUsers);
      const cur = mockDb.getCurrentUser();
      if (cur && ((cleanEmail && cur.email?.toLowerCase() === cleanEmail) || (newReq.linkedUserId && cur.id === newReq.linkedUserId))) {
        mockDb.setCurrentUser({ ...cur, status: 'pending_installation' });
      }
    }

    // Automatic Notification A: Notify Consumer that installation request has been received
    const receivedNotif = buildInstallationReceivedNotification(newReq);
    mockDb.addNotification(receivedNotif);

    mockDb.addAuditLog(
      newReq.linkedUserId || newReq.consumerEmail,
      newReq.consumerName,
      'consumer',
      'Submitted Water Meter Installation Request',
      `Application #${newReq.applicationNumber} submitted for ${newReq.address} (Preferred Date: ${newReq.preferredInstallationDate}).`
    );

    safeBackendFetch('/api/installations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ request: newReq, notification: receivedNotif }),
    }).catch(() => {});

    return newReq;
  },

  updateInstallationRequestStatus: (
    requestId: string,
    updates: {
      status: InstallationStatus;
      confirmedInstallationDate?: string;
      adminRemarks?: string;
      completionDate?: string;
      responsiblePersonnel?: string;
      adminId: string;
      adminName: string;
    }
  ): WaterMeterInstallationRequest | null => {
    const list = getStored<WaterMeterInstallationRequest[]>(KEYS.INSTALLATIONS, []);
    const idx = list.findIndex((r) => r.id === requestId || r.applicationNumber === requestId);
    if (idx === -1) return null;

    const existing = list[idx];
    const now = new Date().toISOString();
    const prevStatus = existing.status;
    const prevConfirmedDate = existing.confirmedInstallationDate || '';
    const nextConfirmedDate =
      updates.confirmedInstallationDate !== undefined
        ? updates.confirmedInstallationDate
        : existing.confirmedInstallationDate;
    const nextRemarks = updates.adminRemarks !== undefined ? updates.adminRemarks.trim() : existing.adminRemarks || '';

    const didStatusChange = prevStatus !== updates.status;
    const didScheduleChange = Boolean(nextConfirmedDate && nextConfirmedDate !== prevConfirmedDate);
    const didRemarksChange = nextRemarks !== (existing.adminRemarks || '');

    if (!didStatusChange && !didScheduleChange && !didRemarksChange && !updates.completionDate && !updates.responsiblePersonnel) {
      return existing;
    }

    const nextValidationStatus: WaterMeterInstallationRequest['accountValidationStatus'] =
      existing.accountValidationStatus === 'validated'
        ? 'validated'
        : updates.status === 'Installed'
          ? 'awaiting_validation'
          : 'pending_installation';

    const historyEntry: InstallationHistoryEntry = {
      id: `HIST-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      status: updates.status,
      timestamp: now,
      actorName: updates.adminName,
      actorRole: 'admin',
      action: didStatusChange
        ? `Updated status from "${prevStatus}" to "${updates.status}"`
        : 'Updated installation schedule / remarks',
      scheduledDate: nextConfirmedDate || existing.preferredInstallationDate,
      remarks:
        nextRemarks ||
        `Installation status updated from "${prevStatus}" to "${updates.status}".`,
    };

    const updatedReq: WaterMeterInstallationRequest = {
      ...existing,
      status: updates.status,
      confirmedInstallationDate: nextConfirmedDate,
      adminRemarks: nextRemarks,
      completionDate:
        updates.status === 'Installed'
          ? updates.completionDate || existing.completionDate || now.split('T')[0]
          : updates.completionDate || existing.completionDate,
      responsiblePersonnel: updates.responsiblePersonnel || existing.responsiblePersonnel,
      accountValidationStatus: nextValidationStatus,
      hasUnreadAdminAlert: false,
      updatedAt: now,
      history: [...(existing.history || []), historyEntry],
    };

    const nextList = [...list];
    nextList[idx] = updatedReq;
    mockDb.saveInstallationRequests(nextList);

    // Sync status onto Consumer record so Admin Consumers table & Consumer Portal stay aligned
    const consumers = mockDb.getConsumers();
    let consumerChanged = false;
    const nextConsumers = consumers.map((c) => {
      const matches =
        c.installationRequestId === updatedReq.id ||
        (updatedReq.applicationNumber && c.applicationNumber === updatedReq.applicationNumber) ||
        (updatedReq.consumerEmail && c.email && c.email.trim().toLowerCase() === updatedReq.consumerEmail);
      if (!matches) return c;
      consumerChanged = true;
      return {
        ...c,
        hasExistingMeter: false,
        installationRequestId: updatedReq.id,
        installationStatus: updatedReq.status,
        accountValidationStatus: nextValidationStatus,
        ...(isRealIssuedAccountNumber(c.accountNumber)
          ? {}
          : { status: (updatedReq.status === 'Cancelled' ? 'installation_not_scheduled' : 'pending_installation') as Consumer['status'] }),
      };
    });
    if (consumerChanged) {
      mockDb.saveConsumers(nextConsumers);
    }

    // Automatic Notifications B, C, D (dispatched whenever status or schedule changes)
    let savedAutoNotif: ConsumerNotification | null = null;
    if (didStatusChange || didScheduleChange) {
      const autoNotif = buildInstallationStatusUpdateNotification(
        updatedReq,
        updates.status,
        updates.adminName,
        nextRemarks
      );
      if (autoNotif) {
        savedAutoNotif = mockDb.addNotification(autoNotif);
      }
    }

    mockDb.addAuditLog(
      updates.adminId,
      updates.adminName,
      'admin',
      `Installation Status Updated: ${updates.status}`,
      `Application #${updatedReq.applicationNumber} (${updatedReq.consumerName}) updated from "${prevStatus}" to "${updates.status}"${nextConfirmedDate ? ` · Schedule: ${nextConfirmedDate}` : ''}${nextRemarks ? ` · Remarks: ${nextRemarks}` : ''}.`
    );

    safeBackendFetch(`/api/installations/${encodeURIComponent(updatedReq.id)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        request: updatedReq,
        notification: savedAutoNotif,
      }),
    }).catch(() => {});

    if (savedAutoNotif) {
      safeBackendFetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(savedAutoNotif),
      }).catch(() => {});
    }

    return updatedReq;
  },

  checkDuplicateMeterSerial: (serialNumber: string, excludeMeterNumber?: string): WaterMeter | undefined => {
    const cleanSerial = (serialNumber || '').trim().toUpperCase();
    if (!cleanSerial) return undefined;
    const meters = mockDb.getMeters();
    return meters.find((m) => {
      if (excludeMeterNumber && m.meterNumber.trim().toUpperCase() === excludeMeterNumber.trim().toUpperCase()) {
        return false;
      }
      return (m.serialNumber || '').trim().toUpperCase() === cleanSerial;
    });
  },

  validateInstallationAndActivateAccount: async (params: {
    requestId: string;
    meterSerialNumber: string;
    meterTagNumber: string;
    rfidTag?: string;
    meterBrand: string;
    meterSize: string;
    accountNumber: string;
    completionDate: string;
    responsiblePersonnel?: string;
    adminId: string;
    adminName: string;
  }): Promise<{
    success: boolean;
    error?: string;
    request?: WaterMeterInstallationRequest;
    consumer?: Consumer;
    meter?: WaterMeter;
  }> => {
    const list = getStored<WaterMeterInstallationRequest[]>(KEYS.INSTALLATIONS, []);
    const reqIdx = list.findIndex((r) => r.id === params.requestId || r.applicationNumber === params.requestId);
    if (reqIdx === -1) {
      return { success: false, error: 'Installation request record not found.' };
    }

    const reqRecord = list[reqIdx];
    if (reqRecord.status !== 'Installed') {
      return {
        success: false,
        error: `Account Number and Meter Tag Number cannot be issued yet because physical installation status is "${reqRecord.status}". Confirm status as "Installed" first.`,
      };
    }

    const cleanSerial = params.meterSerialNumber.trim().toUpperCase();
    const cleanTag = params.meterTagNumber.trim().toUpperCase();
    const cleanAcc = params.accountNumber.replace(/^#/, '').trim().toUpperCase();
    const cleanRfid = params.rfidTag?.trim() ? params.rfidTag.trim().toUpperCase() : undefined;
    const cleanCompletionDate = params.completionDate.trim() || new Date().toISOString().split('T')[0];

    if (!cleanSerial || !cleanTag || !cleanAcc) {
      return {
        success: false,
        error: 'Meter Serial Number, Meter Tag Number, and Account Number are all required.',
      };
    }

    const matchedMobileReader = mockDb.getReaders().find((mr) => {
      if (mr.employmentStatus === 'inactive') return false;
      const routes =
        Array.isArray(mr.assignedRoutes) && mr.assignedRoutes.length > 0
          ? mr.assignedRoutes
          : ([mr.targetRoute, mr.zone].filter(Boolean) as string[]);
      const brgyLower = (reqRecord.barangay || '').trim().toLowerCase();
      return brgyLower ? routes.some((rt) => rt.toLowerCase().includes(brgyLower)) : false;
    });

    const cleanPersonnel =
      params.responsiblePersonnel?.trim() ||
      reqRecord.responsiblePersonnel?.trim() ||
      (matchedMobileReader?.name
        ? `${matchedMobileReader.name} (Auto-Routed via Mobile Terminal)`
        : 'Auto-Assigned via Mobile Field Terminal');

    // Check duplicate Account Number, Meter Tag Number, and Meter Serial Number
    const allConsumers = mockDb.getConsumers();
    const targetEmail = (reqRecord.consumerEmail || '').trim().toLowerCase();
    const isTargetConsumer = (c: Consumer) =>
      (targetEmail && c.email && c.email.trim().toLowerCase() === targetEmail) ||
      (reqRecord.linkedUserId && c.linkedUserId === reqRecord.linkedUserId) ||
      (reqRecord.applicationNumber && c.applicationNumber === reqRecord.applicationNumber);

    const dupAcc = allConsumers.find(
      (c) => !isTargetConsumer(c) && isRealIssuedAccountNumber(c.accountNumber) && c.accountNumber.trim().toUpperCase() === cleanAcc
    );
    if (dupAcc) {
      return {
        success: false,
        error: `Account Number #${cleanAcc} is already assigned to "${dupAcc.name}". Duplicate account numbers are prohibited.`,
      };
    }

    const dupTagConsumer = allConsumers.find(
      (c) => !isTargetConsumer(c) && c.meterNumber && c.meterNumber.trim().toUpperCase() === cleanTag
    );
    if (dupTagConsumer) {
      return {
        success: false,
        error: `Meter Tag Number #${cleanTag} is already assigned to "${dupTagConsumer.name}".`,
      };
    }

    const dupSerial = mockDb.checkDuplicateMeterSerial(cleanSerial, cleanTag);
    if (dupSerial) {
      return {
        success: false,
        error: `Water Meter Serial Number "${cleanSerial}" is already registered on Meter Tag #${dupSerial.meterNumber}.`,
      };
    }

    const now = new Date().toISOString();

    // 1. Register / link physical WaterMeter in Water Meters inventory (serialNumber stored exclusively here!)
    const newMeter: WaterMeter = {
      meterNumber: cleanTag,
      serialNumber: cleanSerial,
      ...(cleanRfid ? { rfidTag: cleanRfid } : {}),
      brand: params.meterBrand || 'EVER',
      type: 'standard',
      size: params.meterSize || '1/2"',
      installationDate: cleanCompletionDate,
      completionDate: cleanCompletionDate,
      installedBy: cleanPersonnel,
      installationRequestId: reqRecord.id,
      applicationNumber: reqRecord.applicationNumber,
      lastReadingDate: cleanCompletionDate,
      lastReadingValue: 0,
      status: 'active',
      linkedAccountNumber: cleanAcc,
      statusUpdatedAt: now,
      statusUpdatedBy: params.adminName,
    };
    await mockDb.saveMeterAsync(newMeter);

    // 2. Activate Consumer record & assign official Account Number and Meter Tag Number
    const cIdx = allConsumers.findIndex(isTargetConsumer);
    const baseConsumer: Consumer =
      cIdx >= 0
        ? allConsumers[cIdx]
        : {
            accountNumber: cleanAcc,
            name: reqRecord.consumerName,
            address: reqRecord.address,
            barangay: reqRecord.barangay,
            barangayId: reqRecord.barangayId || 'BRG-01',
            sitioZone: reqRecord.sitioZone || 'Zone 1',
            contactNumber: reqRecord.contactNumber,
            email: reqRecord.consumerEmail,
            meterNumber: cleanTag,
            status: 'active',
            registrationDate: reqRecord.submissionDate.split('T')[0],
            consumerType: reqRecord.consumerType || 'Residential',
            linkedUserId: reqRecord.linkedUserId,
            isRegistered: true,
          };

    const previousAcc = baseConsumer.accountNumber;
    const activatedConsumer: Consumer = {
      ...baseConsumer,
      accountNumber: cleanAcc,
      meterNumber: cleanTag,
      meterBrand: params.meterBrand || baseConsumer.meterBrand || 'EVER',
      meterSize: params.meterSize || baseConsumer.meterSize || '1/2"',
      status: 'active',
      isRegistered: true,
      applicationNumber: reqRecord.applicationNumber,
      hasExistingMeter: true,
      installationRequestId: reqRecord.id,
      installationStatus: 'Installed',
      accountValidationStatus: 'validated',
    };

    const nextConsumers =
      cIdx >= 0
        ? allConsumers.map((c, idx) => (idx === cIdx ? activatedConsumer : c))
        : [activatedConsumer, ...allConsumers];
    mockDb.saveConsumers(nextConsumers);

    // 3. Activate linked User account
    const allUsers = mockDb.getUsers();
    let matchedUser: User | undefined;
    const nextUsers = allUsers.map((u) => {
      if (u.role === 'admin') return u;
      const matches =
        (targetEmail && u.email && u.email.trim().toLowerCase() === targetEmail) ||
        (reqRecord.linkedUserId && u.id === reqRecord.linkedUserId);
      if (!matches) return u;
      matchedUser = {
        ...u,
        linkedAccountNumber: cleanAcc,
        status: 'active',
      };
      return matchedUser;
    });
    mockDb.saveUsers(nextUsers);

    const cur = mockDb.getCurrentUser();
    if (cur && ((targetEmail && cur.email?.toLowerCase() === targetEmail) || (reqRecord.linkedUserId && cur.id === reqRecord.linkedUserId))) {
      mockDb.setCurrentUser({
        ...cur,
        linkedAccountNumber: cleanAcc,
        status: 'active',
      });
    }

    // 4. Finalize Installation Request record as Validated
    const validationHistory: InstallationHistoryEntry = {
      id: `HIST-VAL-${Date.now()}`,
      status: 'Validated & Activated',
      timestamp: now,
      actorName: params.adminName,
      actorRole: 'admin',
      action: 'Validated Meter Installation & Activated Service Account',
      scheduledDate: cleanCompletionDate,
      remarks: `Installation verified & account activated. Issued Account #${cleanAcc} and Meter Tag #${cleanTag} (Field route assignment handled automatically via Mobile Field Terminal).`,
    };

    const validatedReq: WaterMeterInstallationRequest = {
      ...reqRecord,
      status: 'Installed',
      completionDate: cleanCompletionDate,
      responsiblePersonnel: cleanPersonnel,
      meterSerialNumber: cleanSerial,
      meterBrand: params.meterBrand || 'EVER',
      meterSize: params.meterSize || '1/2"',
      assignedAccountNumber: cleanAcc,
      assignedMeterTagNumber: cleanTag,
      accountValidationStatus: 'validated',
      validatedAt: now,
      validatedBy: params.adminName,
      hasUnreadAdminAlert: false,
      updatedAt: now,
      history: [...(reqRecord.history || []), validationHistory],
    };

    const nextReqs = [...list];
    nextReqs[reqIdx] = validatedReq;
    mockDb.saveInstallationRequests(nextReqs);

    // 5. Send official Account Activated Notification to Consumer (strictly omitting Meter Serial Number!)
    const activationNotifPayload = buildAccountActivatedAfterInstallationNotification({
      consumerName: validatedReq.consumerName,
      consumerEmail: validatedReq.consumerEmail,
      consumerId: activatedConsumer.id || activatedConsumer.linkedUserId,
      userId: activatedConsumer.linkedUserId || matchedUser?.id,
      applicationNumber: validatedReq.applicationNumber,
      installationRequestId: validatedReq.id,
      accountNumber: cleanAcc,
      meterTagNumber: cleanTag,
      adminName: params.adminName,
    });
    const savedNotif = mockDb.addNotification(activationNotifPayload);

    // 6. Push authoritative Consumer, User & Notification to Cloud Firestore and Backend API
    await pushIssuedConsumerToFirestore(activatedConsumer, savedNotif, matchedUser, true, previousAcc);

    safeBackendFetch(`/api/installations/${encodeURIComponent(validatedReq.id)}/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        request: validatedReq,
        consumer: activatedConsumer,
        meter: newMeter,
        notification: savedNotif,
      }),
    }).catch(() => {});

    safeBackendFetch('/api/consumers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(activatedConsumer),
    }).catch(() => {});

    mockDb.addAuditLog(
      params.adminId,
      params.adminName,
      'admin',
      'Validated Meter Installation & Activated Account',
      `Verified installation for ${reqRecord.consumerName} (App #${reqRecord.applicationNumber}). Issued Account #${cleanAcc} and Meter Tag #${cleanTag} (Completed ${cleanCompletionDate} · Field routing handled automatically via Mobile Field Terminal).`
    );

    return {
      success: true,
      request: validatedReq,
      consumer: activatedConsumer,
      meter: newMeter,
    };
  },

  addAuditLog: (userId: string, userName: string, userRole: 'admin' | 'consumer' | 'system' | 'staff' | 'cashier' | 'meter_reader', action: string, details: string): void => {
    const logs = mockDb.getAuditLogs();
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      userId,
      userName,
      userRole,
      action,
      details,
      ipAddress: '192.168.1.' + Math.floor(Math.random() * 254 + 1),
    };
    logs.push(newLog);
    mockDb.saveAuditLogs(logs);
  },

  getTariffConfig: (): WaterTariffConfig => {
    return getActiveTariffConfig();
  },

  saveTariffConfig: (config: WaterTariffConfig): void => {
    saveActiveTariffConfig(config);
    setStored(KEYS.TARIFF_CONFIG, config);
    syncDocToFirestore(COLLECTIONS.SETTINGS, 'tariff_config', config as unknown as Record<string, unknown>);
    safeBackendFetch('/api/tariff-config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    }).catch(() => {});
  },

  initFirestore: (): void => {
    initializeFirestoreSeed({
      users: INITIAL_USERS,
      consumers: INITIAL_CONSUMERS,
      readers: INITIAL_READERS,
      meters: INITIAL_METERS,
      readings: INITIAL_READINGS,
      routes: INITIAL_ROUTES,
      announcements: INITIAL_ANNOUNCEMENTS,
      barangays: INITIAL_BARANGAYS,
    });
  },

  // Retroactively heals & links any previously issued consumer IDs across users, active session, and notifications
  reconcileIssuedAccounts: (): void => {
    try {
      const consumers = getStored<Consumer[]>(KEYS.CONSUMERS, INITIAL_CONSUMERS);
      const users = getStored<User[]>(KEYS.USERS, INITIAL_USERS);
      const notifications = getStored<ConsumerNotification[]>(KEYS.NOTIFICATIONS, []);
      const meters = getStored<WaterMeter[]>(KEYS.METERS, INITIAL_METERS);

      const isRealAcc = (acc?: string) => {
        if (!acc) return false;
        const c = acc.replace(/^#/, '').trim().toUpperCase();
        return Boolean(c && !c.startsWith('PENDING') && c !== 'UNASSIGNED' && c !== 'UNISSUED' && c !== 'NONE' && c !== 'N/A');
      };

      let consumersChanged = false;
      let usersChanged = false;
      let notifsChanged = false;
      let metersChanged = false;

      consumers.forEach(c => {
        if (!isRealAcc(c.accountNumber)) return;

        if (isPendingConsumerStatus(c.status)) {
          c.status = 'active';
          consumersChanged = true;
        }

        const acc = c.accountNumber.replace(/^#/, '').trim().toUpperCase();
        if (c.accountNumber !== acc) {
          c.accountNumber = acc;
          consumersChanged = true;
        }
        if (!c.meterNumber || c.meterNumber.toUpperCase().startsWith('PENDING')) {
          c.meterNumber = `MT-${acc}`;
          consumersChanged = true;
        }

        const cEmail = (c.email || '').trim().toLowerCase();
        const cUid = (c.linkedUserId || '').trim();
        const cName = (c.name || '').trim().toLowerCase();

        // Match corresponding Consumer User account
        const matchedUser = users.find(u => {
          if (u.role === 'admin') return false;
          const uEmail = (u.email || '').trim().toLowerCase();
          const uName = (u.name || '').trim().toLowerCase();
          if (cEmail && uEmail && cEmail === uEmail) return true;
          if (cUid && u.id === cUid) return true;
          if (u.linkedAccountNumber && u.linkedAccountNumber.toUpperCase() === acc) return true;
          if (cName && uName && cName === uName && (!cEmail || !uEmail || cEmail === uEmail)) return true;
          return false;
        });

        if (matchedUser) {
          if (matchedUser.linkedAccountNumber !== acc || matchedUser.status !== 'active') {
            matchedUser.linkedAccountNumber = acc;
            matchedUser.status = 'active';
            usersChanged = true;
          }
          // Heal mismatched synthetic linkedUserId on consumer record
          if (matchedUser.id && c.linkedUserId !== matchedUser.id) {
            c.linkedUserId = matchedUser.id;
            consumersChanged = true;
          }
          if (!c.email && matchedUser.email) {
            c.email = matchedUser.email;
            consumersChanged = true;
          }
        }

        // Heal active currentUser session if currently logged in as this consumer
        const currentSession = mockDb.getCurrentUser();
        if (currentSession && currentSession.role !== 'admin') {
          const sEmail = (currentSession.email || '').trim().toLowerCase();
          const sName = (currentSession.name || '').trim().toLowerCase();
          const isCurrentMatch =
            (cEmail && sEmail && cEmail === sEmail) ||
            (c.linkedUserId && currentSession.id === c.linkedUserId) ||
            (currentSession.linkedAccountNumber && currentSession.linkedAccountNumber.toUpperCase() === acc) ||
            (cName && sName && cName === sName && (!cEmail || !sEmail || cEmail === sEmail));

          if (isCurrentMatch && (currentSession.linkedAccountNumber !== acc || currentSession.status !== 'active')) {
            mockDb.setCurrentUser({
              ...currentSession,
              linkedAccountNumber: acc,
              status: 'active'
            });
          }
        }

        // Heal notifications belonging to this consumer & backfill missing account_issue confirmation for portal users
        const effectiveEmail = (c.email || matchedUser?.email || '').trim().toLowerCase();
        const effectiveUid = (c.linkedUserId || matchedUser?.id || '').trim();

        notifications.forEach(n => {
          const nAcc = (n.accountNumber || '').replace(/^#/, '').trim().toUpperCase();
          if (nAcc === 'ALL' || nAcc === 'BROADCAST' || nAcc === 'DISTRICT') return;
          const nEmail = (n.consumerEmail || '').trim().toLowerCase();
          const samePerson =
            (effectiveEmail && nEmail && effectiveEmail === nEmail) ||
            (nAcc === acc) ||
            (effectiveUid && n.userId === effectiveUid);

          if (samePerson) {
            if (!isRealAcc(n.accountNumber)) {
              n.accountNumber = acc;
              notifsChanged = true;
            }
            if (effectiveEmail && !n.consumerEmail) {
              n.consumerEmail = effectiveEmail;
              notifsChanged = true;
            }
            if (effectiveUid && !n.userId) {
              n.userId = effectiveUid;
              notifsChanged = true;
            }
          }
        });

        const hasPortalIdentity = Boolean(
          matchedUser ||
          c.linkedUserId ||
          acc.startsWith('BRG-') ||
          notifications.some(n => effectiveEmail && n.consumerEmail && n.consumerEmail.toLowerCase() === effectiveEmail)
        );

        if (hasPortalIdentity) {
          let issuedConfirmationNotif = notifications.find(n => {
            if (n.type !== 'account_issue') return false;
            const nTitle = (n.title || '').toLowerCase();
            if (nTitle.includes('registration application submitted')) return false;
            const nAcc = (n.accountNumber || '').replace(/^#/, '').trim().toUpperCase();
            const nEmail = (n.consumerEmail || '').trim().toLowerCase();
            return nAcc === acc || (effectiveEmail && nEmail === effectiveEmail && isRealAcc(n.accountNumber));
          });

          if (!issuedConfirmationNotif) {
            const stableTs = c.registrationDate
              ? `${c.registrationDate}T08:00:00.000Z`
              : '2026-01-01T08:00:00.000Z';
            issuedConfirmationNotif = {
              id: `notif-issued-${acc.replace(/[^a-zA-Z0-9]/g, '')}`,
              accountNumber: acc,
              consumerId: c.id,
              userId: effectiveUid || undefined,
              consumerEmail: effectiveEmail || undefined,
              title: `Official Account Number & Meter Issued!`,
              message: `Your water service account has been officially activated by Tagoloan Water District Administration. Your permanent Account Number is #${acc} and Meter Tag Number is #${c.meterNumber}. Your full dashboard and billing history are now active.`,
              timestamp: stableTs,
              type: 'account_issue',
              read: false
            };
            notifications.unshift(issuedConfirmationNotif);
            notifsChanged = true;

            safeBackendFetch('/api/notifications', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(issuedConfirmationNotif)
            }).catch(() => {});
          }
        }
      });

      const dedupedNotifs = dedupeNotifications(notifications);
      if (dedupedNotifs.length !== notifications.length) {
        notifsChanged = true;
      }

      // Remove any remaining unissued pending twins for consumers who already have an issued record
      const cleanedConsumers = consumers.filter((item, _idx, arr) => {
        if (isRealAcc(item.accountNumber)) return true;
        const iEmail = (item.email || '').trim().toLowerCase();
        const iUid = (item.linkedUserId || '').trim();
        const iName = (item.name || '').trim().toLowerCase();
        const hasIssued = arr.some(o => o !== item && isRealAcc(o.accountNumber) && (
          (iEmail && o.email && o.email.trim().toLowerCase() === iEmail) ||
          (iUid && o.linkedUserId === iUid) ||
          (iName && o.name && o.name.trim().toLowerCase() === iName && (!iEmail || !o.email || o.email.trim().toLowerCase() === iEmail))
        ));
        return !hasIssued;
      });
      if (cleanedConsumers.length !== consumers.length) {
        consumersChanged = true;
      }

      // Ensure every issued consumer with a valid assigned meter has a corresponding WaterMeter record in inventory
      cleanedConsumers.forEach((c) => {
        if (!isRealAcc(c.accountNumber)) return;
        const cleanAcc = c.accountNumber.replace(/^#/, '').trim().toUpperCase();
        const cleanMeter = (c.meterNumber || '').trim();
        if (!cleanMeter || cleanMeter.toUpperCase() === 'UNASSIGNED' || cleanMeter.toUpperCase().startsWith('PENDING')) {
          return;
        }
        const existingMeter = meters.find(
          (m) =>
            m.meterNumber.trim().toLowerCase() === cleanMeter.toLowerCase() ||
            (m.linkedAccountNumber && m.linkedAccountNumber.replace(/^#/, '').trim().toUpperCase() === cleanAcc)
        );
        if (!existingMeter) {
          meters.push({
            meterNumber: cleanMeter,
            brand: c.meterBrand || 'NBI WaterTech',
            rfidTag: c.rfidTag || `RFID-${cleanMeter}`,
            size: c.meterSize || '1/2 inch',
            installationDate: c.registrationDate || '2026-01-15',
            status: 'active',
            linkedAccountNumber: cleanAcc,
          });
          metersChanged = true;
        } else if (!existingMeter.linkedAccountNumber) {
          existingMeter.linkedAccountNumber = cleanAcc;
          metersChanged = true;
        }
      });

      if (consumersChanged) setStored(KEYS.CONSUMERS, cleanedConsumers);
      if (usersChanged) setStored(KEYS.USERS, users);
      if (notifsChanged) setStored(KEYS.NOTIFICATIONS, dedupedNotifs);
      if (metersChanged) setStored(KEYS.METERS, meters);
    } catch (err) {
      console.warn('[mockDb] reconcileIssuedAccounts warning:', err);
    }
  },

  resetDatabase: (): void => {
    localStorage.removeItem(KEYS.USERS);
    localStorage.removeItem(KEYS.CONSUMERS);
    localStorage.removeItem(KEYS.READERS);
    localStorage.removeItem(KEYS.METERS);
    localStorage.removeItem(KEYS.READINGS);
    localStorage.removeItem(KEYS.ROUTES);
    localStorage.removeItem(KEYS.ANNOUNCEMENTS);
    localStorage.removeItem(KEYS.AUDIT_LOGS);
    localStorage.removeItem(KEYS.CURRENT_USER);
    localStorage.removeItem(KEYS.BARANGAYS);
    localStorage.removeItem(KEYS.NOTIFICATIONS);
    localStorage.removeItem(KEYS.REPORTS);
    localStorage.removeItem(KEYS.INSTALLATIONS);
    localStorage.removeItem(KEYS.TARIFF_CONFIG);
  }
};

// Auto initialize Firestore baseline data & self-heal previously issued consumer accounts
mockDb.initFirestore();
mockDb.reconcileIssuedAccounts();

